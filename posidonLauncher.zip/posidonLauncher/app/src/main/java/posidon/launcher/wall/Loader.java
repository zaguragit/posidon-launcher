package posidon.launcher.wall;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.NetworkOnMainThreadException;
import android.view.View;
import android.widget.GridView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

class Loader extends AsyncTask<Void, Void, Wall[]> {

    private Wall[] walls;
    private String TextHolder = "";
    private AsyncTaskListener listener;

    @Override
    protected Wall[] doInBackground(Void... params) {
        String repo = "https://raw.githubusercontent.com/leoxshn/walls/master/";
        try {
            String TextHolder2;
            BufferedReader bufferReader = new BufferedReader(new InputStreamReader(new URL(repo + "index.json").openStream()));
            while ((TextHolder2 = bufferReader.readLine()) != null) TextHolder += TextHolder2;
            bufferReader.close();
            
            JSONObject jobj = new JSONObject(TextHolder);
            JSONArray array = jobj.getJSONArray("walls");
            walls = new Wall[array.length()];
            for (int i = 0; i < array.length(); i++) {
                walls[i] = new Wall();
                walls[i].name = array.getJSONObject(i).getString("name");
                walls[i].author = array.getJSONObject(i).getString("author");
                System.gc();
                try { walls[i].img = BitmapFactory.decodeStream(new URL(repo + array.getJSONObject(i).getString("dir") + "/thumb.jpg").openConnection().getInputStream()); }
                catch (MalformedURLException e) { e.printStackTrace(); }
                catch (IOException e) { e.printStackTrace(); }
                catch (NetworkOnMainThreadException e) { e.printStackTrace(); }
                walls[i].url = repo + array.getJSONObject(i).getString("dir") + "/img.png";
            }
        } catch (Exception e) { e.printStackTrace(); return null; }
        return walls;
    }
    
    public void setListener(AsyncTaskListener listener) {
        this.listener = listener;
    }
    
    public interface AsyncTaskListener {
        void onAsyncTaskFinished(Wall[] walls);
    }
    
    @Override
    protected void onPostExecute(Wall[] walls) {
        if (listener != null) {
            listener.onAsyncTaskFinished(walls);
        }
    }
}