/*
 * Copyright (c) 2019 Leo Shneyderis
 * All rights reserved
 */

package posidon.launcher;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Switch;
import android.widget.TextView;


public class CustomTheme extends AppCompatActivity {

    private SharedPreferences settings;
	private View[] icshapeviews;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
    	settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
		setContentView(R.layout.customtheme);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
		findViewById(R.id.settings).setPadding(0, 0, 0,Tools.getNavbarHeight(this));
		PackageManager pm = getPackageManager();
		icshapeviews = new View[]{findViewById(R.id.icshapedef), findViewById(R.id.icshaperound), findViewById(R.id.icshaperoundrect), findViewById(R.id.icshaperect), findViewById(R.id.icshapesquircle)};

		TextView i = findViewById(R.id.iconpackselector);
		try { i.setText(pm.getApplicationLabel(pm.getApplicationInfo(settings.getString("iconpack", "system"), 0))); }
		catch (PackageManager.NameNotFoundException e) { e.printStackTrace(); }

        final TextView fontname = findViewById(R.id.fontname);
        switch (settings.getInt("fonttheme", R.style.hometheme_posidonsans)) {
			case R.style.hometheme_sansserif:
				fontname.setText("Sans Serif");
				break;
			case R.style.hometheme_posidonsans:
				fontname.setText("Posidon Sans");
				break;
			case R.style.hometheme_monospace:
				fontname.setText("Monospace");
				break;
		}
		findViewById(R.id.fontbox).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				final Dialog d = new Dialog(CustomTheme.this);
				d.setContentView(R.layout.fontlist);
				d.findViewById(R.id.sansserif).setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						d.dismiss();
						settings.edit().putInt("fonttheme", R.style.hometheme_sansserif).apply();
						fontname.setText("Sans Serif");
					}
				});
				d.findViewById(R.id.posidonsans).setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						d.dismiss();
						settings.edit().putInt("fonttheme", R.style.hometheme_posidonsans).apply();
						fontname.setText("Posidon Sans");
					}
				});
				d.findViewById(R.id.monospace).setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						d.dismiss();
						settings.edit().putInt("fonttheme", R.style.hometheme_monospace).apply();
						fontname.setText("Monospace");
					}
				});
				d.show();
			}
		});
	
		((Switch)findViewById(R.id.animatedicons)).setChecked(settings.getBoolean("animatedicons", true));
		((Switch)findViewById(R.id.reshapeicons)).setChecked(settings.getBoolean("reshapeicons", false));
	
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) findViewById(R.id.icshapesettings).setVisibility(View.GONE);
		else {
			icshapeviews[settings.getInt("icshape", 4)].setBackgroundResource(R.drawable.selection);
		}
    }
    
	public void iconpackselector(View view) { startActivity(new Intent(this, IconPackPicker.class)); }

    @Override
    protected void onPause() {
        SharedPreferences.Editor e = settings.edit();
		e.putBoolean("animatedicons", ((Switch)findViewById(R.id.animatedicons)).isChecked());
		e.putBoolean("reshapeicons", ((Switch)findViewById(R.id.reshapeicons)).isChecked());
        e.apply();
		Main.shouldsetapps = true;
		Main.customized = true;
        super.onPause();
    }
	
	@Override
	protected void onResume() {
		super.onResume();
		PackageManager pm = getPackageManager();
		TextView i = findViewById(R.id.iconpackselector);
		try { i.setText(pm.getApplicationLabel(pm.getApplicationInfo(settings.getString("iconpack", "system"), 0))); }
		catch (PackageManager.NameNotFoundException e) { e.printStackTrace(); }
	}
	
	//public void pickcolor(View v) { ColorTools.pickcolor(this, "uibg", settings, 0xDD000000); }
	public void icshapedef(View v) {
		icshapeviews[settings.getInt("icshape", 4)].setBackgroundColor(0x0);
		settings.edit().putInt("icshape", 0).commit();
		v.setBackgroundResource(R.drawable.selection);
	}
	public void icshaperound(View v) {
		icshapeviews[settings.getInt("icshape", 4)].setBackgroundColor(0x0);
		settings.edit().putInt("icshape", 1).commit();
		v.setBackgroundResource(R.drawable.selection);
	}
	public void icshaperoundrect(View v) {
		icshapeviews[settings.getInt("icshape", 4)].setBackgroundColor(0x0);
		settings.edit().putInt("icshape", 2).commit();
		v.setBackgroundResource(R.drawable.selection);
	}
	public void icshaperect(View v) {
		icshapeviews[settings.getInt("icshape", 4)].setBackgroundColor(0x0);
		settings.edit().putInt("icshape", 3).commit();
		v.setBackgroundResource(R.drawable.selection);
	}
	public void icshapesquircle(View v) {
		icshapeviews[settings.getInt("icshape", 4)].setBackgroundColor(0x0);
		settings.edit().putInt("icshape", 4).commit();
		v.setBackgroundResource(R.drawable.selection);
	}
}