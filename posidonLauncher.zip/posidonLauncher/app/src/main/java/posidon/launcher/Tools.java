package posidon.launcher;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.drawable.Animatable2;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;

import androidx.vectordrawable.graphics.drawable.Animatable2Compat;
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat;

import android.os.VibrationEffect;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.util.TypedValue;
import android.view.Display;
import android.view.ViewConfiguration;

import static android.content.Context.VIBRATOR_SERVICE;

public class Tools {

	public static int numtodp(int in, Activity activity){ return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, in, activity.getResources().getDisplayMetrics()); }
	
	public static Bitmap getResizedBitmap(Bitmap bm, int newHeight, int newWidth){
	    int width = bm.getWidth();
	    int height = bm.getHeight();
	    float scaleWidth = ((float) newWidth) / width;
	    float scaleHeight = ((float) newHeight) / height;
	    Matrix matrix = new Matrix();
	    matrix.postScale(scaleWidth, scaleHeight);
	    return Bitmap.createBitmap(bm, 0, 0, width, height, matrix, true);
	}
	
	public static Matrix getResizedMatrix(Bitmap bm, int newHeight, int newWidth){
	    int width = bm.getWidth();
	    int height = bm.getHeight();
	    float scaleWidth = ((float) newWidth) / width;
	    float scaleHeight = ((float) newHeight) / height;
	    Matrix matrix = new Matrix();
	    matrix.postScale(scaleWidth, scaleHeight);
	    return matrix;
	}

	public static void animate(Drawable d) {
		if (d instanceof AnimatedVectorDrawable && android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			final AnimatedVectorDrawable avd = (AnimatedVectorDrawable) d;
			avd.registerAnimationCallback(new Animatable2.AnimationCallback() {
				@Override
				public void onAnimationEnd(Drawable drawable) {
					avd.start();
				}
			});
			avd.start();
		} else if (d instanceof AnimatedVectorDrawableCompat) {
			final AnimatedVectorDrawableCompat avd = (AnimatedVectorDrawableCompat) d;
			avd.registerAnimationCallback(new Animatable2Compat.AnimationCallback() {
				@Override
				public void onAnimationEnd(Drawable drawable) {
					avd.start();
				}
			});
			avd.start();
		}
	}

	public static boolean isinstalled(String packageName, PackageManager packageManager) {
		boolean found = true;
		try { packageManager.getPackageInfo(packageName, 0); }
		catch (PackageManager.NameNotFoundException e) { found = false; }
		return found;
	}

	/*try {
		Object sbs = getSystemService("statusbar");
		Class<?> statusbarManager = Class.forName("android.app.StatusBarManager");
		Method showsb = statusbarManager.getMethod("expandNotificationsPanel");
		showsb.invoke(sbs);
	}
	catch (ClassNotFoundException e) {}
	catch (NoSuchMethodException e) {}
	catch (IllegalAccessException e) {}
	catch (InvocationTargetException e) {} */
	
	private static void blurBitmapWithRenderscript(RenderScript rs, Bitmap bitmap2, float radius) {
		final Allocation input = Allocation.createFromBitmap(rs, bitmap2);
		final Allocation output = Allocation.createTyped(rs, input.getType());
		final ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
		// must be >0 and <= 25
		script.setRadius(radius);
		script.setInput(input);
		script.forEach(output);
		output.copyTo(bitmap2);
	}
	
	static Bitmap drawable2bitmap(Drawable drawable) {
		Bitmap bitmap;
		
		if (drawable instanceof BitmapDrawable) {
			BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
			if(bitmapDrawable.getBitmap() != null) {
				return bitmapDrawable.getBitmap();
			}
		}
		
		if(drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
			bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888); // Single color bitmap will be created of 1x1 pixel
		} else {
			bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
		}
		
		Canvas canvas = new Canvas(bitmap);
		drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
		drawable.draw(canvas);
		return bitmap;
	}
	
	static Bitmap wallblurbitmap(Context context, float numba) {
		Bitmap bitmap = null;
		if (numba > 0) try {
			WallpaperManager wallpaperManager = WallpaperManager.getInstance(context);
			Drawable drawable = wallpaperManager.getDrawable();
			bitmap = Tools.drawable2bitmap(drawable);
			if (bitmap.getHeight() / bitmap.getWidth() < context.getResources().getDisplayMetrics().heightPixels / context.getResources().getDisplayMetrics().widthPixels) {
				bitmap = Bitmap.createScaledBitmap(
						bitmap,
						(int) ((float) context.getResources().getDisplayMetrics().heightPixels * bitmap.getWidth()/bitmap.getHeight()),
						context.getResources().getDisplayMetrics().heightPixels,
						false);
				
				bitmap = Bitmap.createBitmap(
						bitmap, 0, 0,
						context.getResources().getDisplayMetrics().widthPixels,
						context.getResources().getDisplayMetrics().heightPixels);
			} else if (bitmap.getHeight() / bitmap.getWidth() > context.getResources().getDisplayMetrics().heightPixels / context.getResources().getDisplayMetrics().widthPixels) {
				bitmap = Bitmap.createScaledBitmap(
						bitmap,
						context.getResources().getDisplayMetrics().widthPixels,
						context.getResources().getDisplayMetrics().widthPixels * bitmap.getHeight() / bitmap.getWidth(),
						true);
				bitmap = Bitmap.createBitmap(
						bitmap, 0, 0,
						context.getResources().getDisplayMetrics().widthPixels,
						context.getResources().getDisplayMetrics().heightPixels);
			}
			float resdiv = numba / 5;
			if (resdiv < 1) resdiv = 1;
			bitmap = Bitmap.createScaledBitmap(bitmap, (int)(bitmap.getWidth()/resdiv), (int)(bitmap.getHeight()/resdiv), false);
			Tools.blurBitmapWithRenderscript(RenderScript.create(context), bitmap, numba);
		} catch (SecurityException ignored) {}
		return bitmap;
	}
	
	
	public static Bitmap centerCropWallpaper(Context context, Bitmap wallpaper){
		int scaledWidth = (int) ((float) context.getResources().getDisplayMetrics().heightPixels * wallpaper.getWidth()/wallpaper.getHeight());
		
		Bitmap scaledWallpaper = Bitmap.createScaledBitmap(
				wallpaper,
				scaledWidth,
				context.getResources().getDisplayMetrics().heightPixels,
				false);
		
		scaledWallpaper = Bitmap.createBitmap(
				scaledWallpaper,
				(scaledWidth - context.getResources().getDisplayMetrics().widthPixels) / 2,
				0,
				context.getResources().getDisplayMetrics().widthPixels,
				context.getResources().getDisplayMetrics().heightPixels);
		
		return scaledWallpaper;
	}
	
	
	public static int getNavbarHeight(Context c) {
		int id = c.getResources().getIdentifier("config_showNavigationBar", "bool", "android");
		if(id > 0 && c.getResources().getBoolean(id) && !ViewConfiguration.get(c).hasPermanentMenuKey()) {
			Resources resources = c.getResources();
			int orientation = resources.getConfiguration().orientation;
			int resourceId;
			if (isTablet(c)) resourceId = resources.getIdentifier(orientation == Configuration.ORIENTATION_PORTRAIT ? "navigation_bar_height" : "navigation_bar_height_landscape", "dimen", "android");
			else resourceId = resources.getIdentifier(orientation == Configuration.ORIENTATION_PORTRAIT ? "navigation_bar_height" : "navigation_bar_width", "dimen", "android");
			if (resourceId > 0) return resources.getDimensionPixelSize(resourceId);
		}
		return 0;
	}
	
	public static int getStatusBarHeight(Context c) {
		int resourceId = c.getResources().getIdentifier("status_bar_height", "dimen", "android");
		if (resourceId > 0) return c.getResources().getDimensionPixelSize(resourceId);
		return 0;
	}
	
	private static boolean isTablet(Context c) { return (c.getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_LARGE; }
	
	public static void vibrate(Context context) {
		SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(context);
		((Vibrator) context.getSystemService(VIBRATOR_SERVICE)).vibrate(settings.getInt("hapticfeedback", 14));
	}
}
