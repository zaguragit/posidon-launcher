package posidon.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

class SearchAdapter extends BaseAdapter {

    private final Context context;
    private final Pac[] pacsForAdapter;

    public SearchAdapter(Context c, Pac[] pacs){
        context = c;
        pacsForAdapter = pacs;
    }

	@Override
    public int getCount() {
        return pacsForAdapter.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    static class ViewHolder {
        ImageView icon;
        TextView text;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(context);
        final ViewHolder viewHolder;
        LayoutInflater li = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView==null) {
            convertView = li.inflate(R.layout.listitem, null);
            viewHolder = new ViewHolder();
            viewHolder.icon = convertView.findViewById(R.id.iconimg);
            viewHolder.text = convertView.findViewById(R.id.icontxt);
            convertView.setTag(viewHolder);
        } else viewHolder = (ViewHolder)convertView.getTag();

        viewHolder.icon.setImageDrawable(pacsForAdapter[position].icon);
        viewHolder.text.setText(pacsForAdapter[position].label);
        viewHolder.text.setTextColor(settings.getInt("searchtxtcolor", 0xFFFFFFFF));
        int p = settings.getInt("icsize", 1);
        int appsize = 0;
        if (p == 0) appsize = (int) (context.getResources().getDisplayMetrics().density * 64);
        else if (p == 1) appsize = (int) (context.getResources().getDisplayMetrics().density * 72);
        else if (p == 2) appsize = (int) (context.getResources().getDisplayMetrics().density * 96);
        viewHolder.icon.getLayoutParams().height = appsize;
        viewHolder.icon.getLayoutParams().width = appsize;
        return convertView;
    }
}