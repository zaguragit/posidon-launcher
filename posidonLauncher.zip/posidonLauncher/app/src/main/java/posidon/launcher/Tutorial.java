package posidon.launcher;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import android.preference.PreferenceManager;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;

public class Tutorial extends AppCompatActivity {
	
	private final int[] stylebtns = new int[]{R.id.stylepixel, R.id.styleoneui, R.id.styleios, R.id.styleposidon};
	private int selectedstyle = -1;
	private boolean done = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tutorial);
		for (int i = 0; i < stylebtns.length; i++) {
			final int finalI = i;
			findViewById(stylebtns[i]).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (selectedstyle != -1) findViewById(stylebtns[selectedstyle]).setBackground(getDrawable(R.drawable.roundbuttonbg));
					GradientDrawable d = (GradientDrawable) Objects.requireNonNull(getDrawable(R.drawable.roundbuttonbg)).mutate();
					d.setColor(getResources().getColor(R.color.accent));
					findViewById(stylebtns[finalI]).setBackground(d);
					selectedstyle = finalI;
					checkdone();
				}
			});
		}
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
			findViewById(R.id.storagecard).setVisibility(View.GONE);
		}
	}
	
	private void checkdone() {
		if (selectedstyle != -1) {
			done = true;
			TextView t = findViewById(R.id.done);
			t.setTextColor(0xFFFFFFFF);
			t.setBackgroundColor(getResources().getColor(R.color.accent));
		}
	}
	
	public void grantNotificationAccess(View v) {
		if (!NotificationManagerCompat.getEnabledListenerPackages (getApplicationContext()).contains(getApplicationContext().getPackageName())) {
			getApplicationContext().startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
			checkdone();
		} else Toast.makeText(this, "Notification access already granted", Toast.LENGTH_LONG).show();
	}
	
	public void grantStorageAccess(View v) {
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0); }
			checkdone();
		} else Toast.makeText(this, "Storage access already granted", Toast.LENGTH_LONG).show();
	}
	
	public void done(View v) {
		if (done) {
			SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
			if (selectedstyle == 0) {
				settings.edit()
						.putInt("icshape", 1)//circle
						.putInt("dockcolor", 0x66ffffff)
						//.putBoolean("blur", false)
						.apply();
				
			} else if (selectedstyle == 1) {
				settings.edit()
						//.putInt("icshape", 4)//squircle
						.putInt("dockcolor", 0x0)
						//.putBoolean("blur", true)
						.apply();
				
			} else if (selectedstyle == 2) {
				settings.edit()
						.putInt("icshape", 2)//roundrect
						.putInt("dockcolor", 0x66eeeeee)
						.putBoolean("blur", true)
						.apply();
			}
			settings.edit()
					.putBoolean("init", false)
					.putString("ic1", Tools.isinstalled("com.whatsapp", getPackageManager()) ? "com.whatsappcom.whatsapp.Main" : "com.android.mmscom.android.mms.ui.ConversationList")
					.putString("ic2", "")
					.putString("ic3", "")
					.putString("ic4", "")
					.putString("ic5", "")
					.apply();
			startActivity(new Intent(this, Main.class));
			finish();
		}
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		checkdone();
	}
}
