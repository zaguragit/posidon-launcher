package posidon.launcher;

import android.app.Notification;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import org.jetbrains.annotations.NotNull;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.NotificationViewHolder> {

	private final Context context;
	private final SharedPreferences settings;
	private final StatusBarNotification[] notifications;

	NotificationsAdapter(Context context, SharedPreferences settings) {
		this.context = context;
		this.settings = settings;
		this.notifications = NotificationListener.notifications;
	}

	static class NotificationViewHolder extends RecyclerView.ViewHolder {
		private final View view;
		NotificationViewHolder(View v) {
			super(v);
			view = v;
		}
	}

	@NotNull
	@Override
	public NotificationViewHolder onCreateViewHolder(@NotNull ViewGroup parent, int type) {
		View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.notificationcard, parent, false);
		return new NotificationViewHolder(v);
	}

	@Override
	public void onBindViewHolder(@NotNull final NotificationViewHolder holder, int position) {
		Bundle extras = notifications[position].getNotification().extras;
		((TextView)holder.view.findViewById(R.id.titletxt)).setText(extras.getCharSequence(Notification.EXTRA_TITLE));
		((TextView)holder.view.findViewById(R.id.titletxt)).setTextColor(settings.getInt("notificationtitlecolor", 0xFF111213));
		((TextView)holder.view.findViewById(R.id.txt)).setText(extras.getCharSequence(Notification.EXTRA_TEXT));
		((TextView)holder.view.findViewById(R.id.txt)).setTextColor(settings.getInt("notificationtxtcolor", 0xFF252627));
		((CardView)holder.view.findViewById(R.id.card)).setRadius(context.getResources().getDisplayMetrics().density * settings.getInt("feedcardradius", 15));
		((CardView)holder.view.findViewById(R.id.card)).setCardBackgroundColor(settings.getInt("notificationbgcolor", 0xFFFFFFFF));
		try { ((ImageView)holder.view.findViewById(R.id.iconimg)).setImageDrawable(
					context.createPackageContext(notifications[position].getPackageName(), 0)
					.getResources().getDrawable(notifications[position].getNotification().icon));
			ColorStateList colorlist = new ColorStateList(new int[][]{{0, 0}}, new int[]{notifications[position].getNotification().color});
			((ImageView)holder.view.findViewById(R.id.iconimg)).setImageTintList(colorlist);
		} catch (PackageManager.NameNotFoundException e) { e.printStackTrace(); }
	}

	@Override
	public int getItemCount() { return NotificationListener.notifications.length; }
}
