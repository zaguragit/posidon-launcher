package posidon.launcher.wall;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import posidon.launcher.R;

class WallpaperAdapter extends BaseAdapter {

    private final Context context;
    private final Wall[] walls;

    WallpaperAdapter(Context c, Wall[] walllist){
        context = c;
        walls = walllist;
    }

	@Override
    public int getCount() { return walls.length; }
    @Override
    public Object getItem(int position) { return null; }
    @Override
    public long getItemId(int position) { return 0; }
    
    static class ViewHolder {
        ImageView pic;
        TextView label;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        LayoutInflater li = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null){
            convertView = li.inflate(R.layout.wallitem, null);
            viewHolder = new ViewHolder();
            viewHolder.pic = convertView.findViewById(R.id.pic);
            viewHolder.label = convertView.findViewById(R.id.label);
            convertView.setTag(viewHolder);
        } else viewHolder = (ViewHolder)convertView.getTag();
        try { viewHolder.pic.setImageBitmap(walls[position].img); }
        catch (NullPointerException ignored) {}
        viewHolder.label.setText(walls[position].name);
        return convertView;
    }
}