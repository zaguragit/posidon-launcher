package posidon.launcher;

import android.app.ActivityOptions;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;

class DrawerClickListener implements AdapterView.OnItemClickListener {

    private final Context context;
    private final Pac[] pacsForAdapter;

    public DrawerClickListener(Context c, Pac[] pacs){
        context = c;
        pacsForAdapter = pacs;
    }

	@Override
    public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
        try {
            Intent launchintent = new Intent(Intent.ACTION_MAIN);
            launchintent.setComponent(new ComponentName(pacsForAdapter[position].packageName, pacsForAdapter[position].name));
            launchintent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(launchintent, ActivityOptions.makeCustomAnimation(context, R.anim.appopen, R.anim.slidedown).toBundle());
        } catch (Exception ignored) {}
    }
}
