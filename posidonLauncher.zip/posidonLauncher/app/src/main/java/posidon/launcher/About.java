package posidon.launcher;

import android.app.ActivityOptions;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.net.URL;

public class About extends Activity {

	private SharedPreferences settings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        setContentView(R.layout.about);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
		findViewById(R.id.settings).setPadding(0, 0, 0,Tools.getNavbarHeight(this));
        TextView nameversion = findViewById(R.id.appname);
        nameversion.setText(getString(R.string.app_name) + " - " + BuildConfig.VERSION_NAME);
        new loadprofilepics().execute();
        Tools.animate(((ImageView) findViewById(R.id.devprofile)).getDrawable());

        findViewById(R.id.maincard).setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View v) {
				if (settings.getBoolean("devoptionsenabled", false)) {
					settings.edit().putBoolean("devoptionsenabled", false).apply();
					Toast.makeText(About.this, "Developer mode disabled", Toast.LENGTH_SHORT).show();
				} else {
					settings.edit().putBoolean("devoptionsenabled", true).apply();
					Toast.makeText(About.this, "Developer mode enabled", Toast.LENGTH_SHORT).show();
				}
				return true;
			}
		});
	}
	
	public void opentwitter(View v) {
		Uri uri = Uri.parse("https://mobile.twitter.com/posidonapp");
		Intent i = new Intent(Intent.ACTION_VIEW, uri);
		startActivity(i, ActivityOptions.makeCustomAnimation(this, R.anim.slideup, R.anim.slidedown).toBundle());
	}
	
	public void openwebsite(View v) {
		Uri uri = Uri.parse("https://leoxshn.github.io/posidon");
		Intent i = new Intent(Intent.ACTION_VIEW, uri);
		startActivity(i, ActivityOptions.makeCustomAnimation(this, R.anim.slideup, R.anim.slidedown).toBundle());
	}
	
	class loadprofilepics extends AsyncTask {
    	
    	Bitmap bmp = null;
		
		@Override
		protected Object doInBackground(Object[] objects) {
			try { bmp = BitmapFactory.decodeStream(new URL("https://pbs.twimg.com/profile_images/1076860543779012608/FDJy-1jY_400x400.jpg").openConnection().getInputStream()); }
			catch (IOException e) { e.printStackTrace(); }
			return null;
		}
		
		@Override
		protected void onPostExecute(Object o) {
			((ImageView)findViewById(R.id.sajidshaikprofile)).setImageBitmap(bmp);
		}
	}
}