package posidon.launcher;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.Objects;

class DockMenu {
    
    private final BottomSheetDialog bottomdialog;
    
    DockMenu(Main main, final Window window, Pac pac) {
        Tools.vibrate(main);
        bottomdialog = new BottomSheetDialog(main, R.style.longpressmenusheet);
        bottomdialog.setContentView(R.layout.dock);
        Objects.requireNonNull(bottomdialog.getWindow()).findViewById(R.id.design_bottom_sheet).setBackgroundColor(0x0);
        setdock(main, bottomdialog.findViewById(R.id.realdock), pac, main);
    
        final View homescreen = window.getDecorView().findViewById(android.R.id.content);
        final View page = homescreen.findViewById(R.id.homeview);
        homescreen.findViewById(R.id.realdock).setVisibility(View.GONE);
        page.animate().scaleX(0.7f).scaleY(0.7f).translationY((float)-page.getHeight()/14).setDuration(100L);
        page.setBackground(main.getDrawable(R.drawable.page));
        window.setBackgroundDrawableResource(R.drawable.blackgradient);
        
        bottomdialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                page.animate().scaleX(1).scaleY(1).translationY(0).setDuration(100L);
                page.setBackgroundColor(0x0);
                window.setBackgroundDrawableResource(android.R.color.transparent);
                homescreen.findViewById(R.id.realdock).setVisibility(View.VISIBLE);
            }
        });
        bottomdialog.show();
    }
    
    private void setdock(Context context, View dock, final Pac pac, final Main main) {
        final SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(context);
        int p = settings.getInt("dockicsize", 1);
        int appsize = 0;
        if (p == 0) appsize = (int) (context.getResources().getDisplayMetrics().density * 64);
        else if (p == 1) appsize = (int) (context.getResources().getDisplayMetrics().density * 72);
        else if (p == 2) appsize = (int) (context.getResources().getDisplayMetrics().density * 96);
        int[] txt = {R.id.icontxt1, R.id.icontxt2, R.id.icontxt3, R.id.icontxt4, R.id.icontxt5, R.id.icontxt6, R.id.icontxt7};
        int[] img = {R.id.iconimg1, R.id.iconimg2, R.id.iconimg3, R.id.iconimg4, R.id.iconimg5, R.id.iconimg6, R.id.iconimg7};
        int icnum = settings.getInt("dockiccount", 5);
        int[] icids = {R.id.ic1, R.id.ic2, R.id.ic3, R.id.ic4, R.id.ic5, R.id.ic6, R.id.ic7};
        final String[] items = {"ic1", "ic2", "ic3", "ic4", "ic5", "ic6", "ic7"};
        for (int x = 0; x < icnum; x++) {
            dock.findViewById(icids[x]).setVisibility(View.VISIBLE);
            ImageView ic = dock.findViewById(img[x]);
            ic.getLayoutParams().height = appsize;
            ic.getLayoutParams().width = appsize;
            ic.setImageDrawable(context.getDrawable(R.drawable.page));
            TextView t = dock.findViewById(txt[x]);
            if (settings.getBoolean("docklabelsenabled", false)) t.setVisibility(View.VISIBLE);
            else t.setVisibility(View.GONE);
            final int fx = x;
            dock.findViewById(icids[x]).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    bottomdialog.dismiss();
                    settings.edit().putString(items[fx], pac.packageName + pac.name).apply();
                    main.setdock();
                    main.behavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                }
            });
        }
        dock.findViewById(R.id.docksearchbar).setVisibility(View.GONE);
        dock.findViewById(R.id.dockcontainer).setPadding(0, 0, 0, (int)(settings.getInt("dockbottompadding", 10) * context.getResources().getDisplayMetrics().density));
    
        ShapeDrawable bg = new ShapeDrawable();
        int tr = settings.getInt("dockradius", 30);
        bg.setShape(new RoundRectShape(new float[]{tr, tr ,tr, tr, 0, 0, 0, 0}, null, null));
        int color = settings.getInt("dockcolor", 0x88000000);
        bg.getPaint().setColor(color);
        dock.setBackground(bg);
    }
}
