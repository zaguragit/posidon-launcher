/*
 * Copyright (c) 2019 Leo Shneyderis
 * All rights reserved
 */

package posidon.launcher;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;


public class CustomDock extends AppCompatActivity {

    private SharedPreferences settings;
    private SeekBar icsize;
	private SeekBar iccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
		super.onCreate(savedInstanceState);
        setContentView(R.layout.customdock);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        findViewById(R.id.settings).setPadding(0, 0, 0,Tools.getNavbarHeight(this));

        icsize = findViewById(R.id.dockiconsizeslider);
        icsize.setProgress(settings.getInt("dockicsize", 1));

        iccount = findViewById(R.id.dockiconcountslider);
        iccount.setProgress(settings.getInt("dockiccount", 5));
        final TextView c = findViewById(R.id.iccountnum);
        c.setText(String.valueOf(settings.getInt("dockiccount", 5)));
        iccount.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { c.setText(String.valueOf(progress)); }
        });

        Switch docklabelswitch = findViewById(R.id.docklabelsenabled);
        docklabelswitch.setChecked(settings.getBoolean("docklabelsenabled", false));

        findViewById(R.id.colorprev).setBackground(ColorTools.colorcircle(settings.getInt("dockcolor", 0x88000000)));

        ((SeekBar)findViewById(R.id.dockradiusslider)).setProgress(settings.getInt("dockradius", 30));
    
        SeekBar bottompadding = findViewById(R.id.bottompaddingslider);
        bottompadding.setProgress(settings.getInt("dockbottompadding", 10));
        ((TextView)findViewById(R.id.bottompadding)).setText(String.valueOf(settings.getInt("dockbottompadding", 10)));
        bottompadding.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                ((TextView)findViewById(R.id.bottompadding)).setText(String.valueOf(progress));
                settings.edit().putInt("dockbottompadding", progress).apply();
            }
        });
    }

    public void pickcolor(View v) {
        ColorTools.pickcolor(this, "dockcolor", settings, 0x88000000);
    }

    @Override
    protected void onPause() {
        overridePendingTransition(R.anim.slideup, R.anim.slidedown);
        SharedPreferences.Editor e = settings.edit();
		e.putInt("dockicsize", icsize.getProgress());
		e.putInt("dockiccount", iccount.getProgress());
		Switch docklabelswitch = findViewById(R.id.docklabelsenabled);
		e.putBoolean("docklabelsenabled", docklabelswitch.isChecked());
        e.putInt("dockradius", ((SeekBar)findViewById(R.id.dockradiusslider)).getProgress());
        e.apply();
        Main.customized = true;
        super.onPause();
    }
}