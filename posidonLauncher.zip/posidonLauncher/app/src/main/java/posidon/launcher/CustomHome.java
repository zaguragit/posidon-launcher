/*
 * Copyright (c) 2019 Leo Shneyderis
 * All rights reserved
 */

package posidon.launcher;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextClock;
import android.widget.TextView;

public class CustomHome extends AppCompatActivity {

	private SharedPreferences settings;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
		super.onCreate(savedInstanceState);
		setContentView(R.layout.customhome);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
		findViewById(R.id.settings).setPadding(0, 0, 0,Tools.getNavbarHeight(this));
		
		findViewById(R.id.clockcolorprev).setBackground(ColorTools.colorcircle(settings.getInt("clockcolor", 0xFFFFFFFF)));
		
		String dateformat = settings.getString("datef", getResources().getString(R.string.defaultdateformat));
		final TextClock datefprev = findViewById(R.id.datefprev);
		final EditText dateftxt = findViewById(R.id.dateformat);
		dateftxt.addTextChangedListener(new TextWatcher() {
			public void afterTextChanged(Editable s) {}
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				String i = dateftxt.getText().toString();
				datefprev.setFormat12Hour(i);
				datefprev.setFormat24Hour(i);
			}
		});
		dateftxt.setText(dateformat, TextView.BufferType.EDITABLE);
		
		Switch feedswitch = findViewById(R.id.feedenabled);
		feedswitch.setChecked(settings.getBoolean("feedenabled", true));
		Switch hidefeedswitch = findViewById(R.id.hidefeed);
		hidefeedswitch.setChecked(settings.getBoolean("hidefeed", false));
		EditText feedurl = findViewById(R.id.feedurl);
		feedurl.setText(settings.getString("feedurl", "www.androidauthority.com/feed"));
		
		SeekBar newscardradiusslider = findViewById(R.id.newscardradiusslider);
		newscardradiusslider.setProgress(settings.getInt("feedcardradius", 15));
		final TextView newscardradiusnum = findViewById(R.id.newscardradiusnum);
		newscardradiusnum.setText(String.valueOf(settings.getInt("feedcardradius", 15)));
		newscardradiusslider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				newscardradiusnum.setText(String.valueOf(progress));
				settings.edit().putInt("feedcardradius", progress).apply();
			}
		});
		findViewById(R.id.newscardbgprev).setBackground(ColorTools.colorcircle(settings.getInt("newscardcolor", 0xFF252627)));
		findViewById(R.id.newscardtxtprev).setBackground(ColorTools.colorcircle(settings.getInt("newscardtxtcolor", 0xFFFFFFFF)));
		((Switch)findViewById(R.id.newscardenableimg)).setChecked(settings.getBoolean("newscardimgenabled", true));
		((Switch)findViewById(R.id.newscardblackgradient)).setChecked(settings.getBoolean("newscardblackgradient", true));
		
		
		findViewById(R.id.notificationtitlecolorprev).setBackground(ColorTools.colorcircle(settings.getInt("notificationtitlecolor", 0xFF111213)));
		findViewById(R.id.notificationtxtcolorprev).setBackground(ColorTools.colorcircle(settings.getInt("notificationtxtcolor", 0xFF252627)));
		findViewById(R.id.notificationbgprev).setBackground(ColorTools.colorcircle(settings.getInt("notificationbgcolor", 0xFFFFFFFF)));
	}

	public void pickclockcolor(View v) { ColorTools.pickcolor(this, "clockcolor", settings, 0xFFFFFFFF); }
	public void picknewscardcolor(View v) { ColorTools.pickcolor(this, "newscardcolor", settings, 0xFF252627); }
	public void picknewscardtxtcolor(View v) { ColorTools.pickcolor(this, "newscardtxtcolor", settings, 0xFFFFFFFF); }
	public void picknotificationtitlecolor(View v) { ColorTools.pickcolor(this, "notificationtitlecolor", settings, 0xFF111213); }
	public void picknotificationtxtcolor(View v) { ColorTools.pickcolor(this, "notificationtxtcolor", settings, 0xFF252627); }
	public void picknotificationcolor(View v) { ColorTools.pickcolor(this, "notificationbgcolor", settings, 0xFFFFFFFF); }

	@Override
	protected void onPause() {
		overridePendingTransition(R.anim.slideup, R.anim.slidedown);
		SharedPreferences.Editor e = settings.edit();
		EditText dateftxt = findViewById(R.id.dateformat);
		e.putString("datef", dateftxt.getText().toString());
		Switch feedswitch = findViewById(R.id.feedenabled);
		e.putBoolean("feedenabled", feedswitch.isChecked());
		EditText feedurl = findViewById(R.id.feedurl);
		e.putString("feedurl", feedurl.getText().toString());
		Switch hidefeedswitch = findViewById(R.id.hidefeed);
		e.putBoolean("hidefeed", hidefeedswitch.isChecked());
		e.putBoolean("newscardimgenabled", ((Switch)findViewById(R.id.newscardenableimg)).isChecked());
		e.putBoolean("newscardblackgradient", ((Switch)findViewById(R.id.newscardblackgradient)).isChecked());
		e.apply();
		Main.customized = true;
		super.onPause();
	}
}