package posidon.launcher;

import android.graphics.Bitmap;

class FeedItem {
			final String title;
			final String link;
			final Bitmap img;
			FeedItem(String title, String link, Bitmap img) {
				this.title = title;
				this.link = link;
				this.img = img;
			}
		}