/*
 * Copyright (c) 2019 Leo Shneyderis
 * All rights reserved
 */

package posidon.launcher;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.SeekBar;
import android.widget.Switch;

public class CustomOther extends AppCompatActivity {
	
	private SharedPreferences settings;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
		super.onCreate(savedInstanceState);
		setContentView(R.layout.customother);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
		findViewById(R.id.settings).setPadding(0, 0, 0,Tools.getNavbarHeight(this));
		((Switch)findViewById(R.id.hidestatus)).setChecked(settings.getBoolean("hidestatus", false));
		((Switch)findViewById(R.id.mnmlstatus)).setChecked(settings.getBoolean("mnmlstatus", false));
		SeekBar hapticbar = findViewById(R.id.hapticbar);
		hapticbar.setProgress(settings.getInt("hapticfeedback", 14));
		hapticbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				Tools.vibrate(CustomOther.this);
				settings.edit().putInt("hapticfeedback", ((SeekBar)findViewById(R.id.hapticbar)).getProgress()).apply();
			}
		});
	}

	public void pickclockcolor(View v) { ColorTools.pickcolor(this, "clockcolor", settings, 0xFFFFFFFF); }
	public void pickclocksecolor(View v) { ColorTools.pickcolor(this, "clocksecolor", settings, 0xFFFFFFFF); }
	public void stop(View v) { System.exit(0); }

	@Override
	protected void onPause() {
		overridePendingTransition(R.anim.slideup, R.anim.slidedown);
		SharedPreferences.Editor e = settings.edit();
		e.putBoolean("hidestatus", ((Switch)findViewById(R.id.hidestatus)).isChecked());
		e.putBoolean("mnmlstatus", ((Switch)findViewById(R.id.mnmlstatus)).isChecked());
		e.apply();
		Main.customized = true;
		super.onPause();
	}
}