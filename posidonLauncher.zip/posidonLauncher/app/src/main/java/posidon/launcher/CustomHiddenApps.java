/*
 * Copyright (c) 2019 Leo Shneyderis
 * All rights reserved
 */

package posidon.launcher;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.preference.PreferenceManager;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class CustomHiddenApps extends AppCompatActivity {

	private PackageManager pm;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.customhiddenapps);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
		findViewById(R.id.settings).setPadding(0, 0, 0,Tools.getNavbarHeight(this));
		pm = getPackageManager();
		setapps((ListView)findViewById(R.id.list));
	}

	private void setapps(ListView list) {
		final Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
		mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
		List<ResolveInfo> pacslist = pm.queryIntentActivities(mainIntent, 0);
		Pac[] pacs = new Pac[pacslist.size()];
		for (int i = 0; i < pacslist.size(); i++) {
			pacs[i] = new Pac();
			pacs[i].icon = pacslist.get(i).loadIcon(pm);
			pacs[i].packageName = pacslist.get(i).activityInfo.packageName;
			pacs[i].name = pacslist.get(i).activityInfo.name;
			pacs[i].label = pacslist.get(i).loadLabel(pm).toString();
		}
		new SortApps().exchange_sort(pacs);
		list.setAdapter(new ListAdapter(this, pacs));
	}

	@Override
	protected void onPause() {
		overridePendingTransition(R.anim.slideup, R.anim.slidedown);
		super.onPause();
		Main.shouldsetapps = true;
		Main.customized = true;
	}
	
	class ListAdapter extends BaseAdapter {
	
		private final Context context;
		private final Pac[] pacsForAdapter;
	
		ListAdapter(Context c, Pac[] pacs){
			context = c;
			pacsForAdapter = pacs;
		}
	
		@Override
		public int getCount() {
			return pacsForAdapter.length;
		}
	
		@Override
		public Object getItem(int position) {
			return null;
		}
	
		@Override
		public long getItemId(int position) {
			return 0;
		}
	
		class ViewHolder{
			ImageView icon;
			TextView text;
		}
	
		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			final SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(context);
			ViewHolder viewHolder;
			LayoutInflater li = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
	
			if (convertView==null){
				convertView = li.inflate(R.layout.listitem, null);
				viewHolder = new ViewHolder();
				viewHolder.icon = convertView.findViewById(R.id.iconimg);
				viewHolder.text = convertView.findViewById(R.id.icontxt);
				convertView.setTag(viewHolder);
			}
			else viewHolder = (ViewHolder)convertView.getTag();
			viewHolder.icon.setImageDrawable(pacsForAdapter[position].icon);
			viewHolder.text.setText(pacsForAdapter[position].label);
			int p = settings.getInt("icsize", 1);
			if (p == 0) {viewHolder.icon.setPadding(64, 64, 64, 64);}
			else if (p == 1) {viewHolder.icon.setPadding(32, 32, 32, 32);}
			else if (p == 2) {viewHolder.icon.setPadding(0, 0, 0, 0);}
			final View finalConvertView = convertView;
	
			final boolean hidden = settings.getBoolean(pacsForAdapter[position].packageName + "/" + pacsForAdapter[position].name + "?hidden", false);
			if (hidden) finalConvertView.setBackgroundColor(0x33ff0000);
			else finalConvertView.setBackgroundColor(0x0);
			convertView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (hidden) {
						finalConvertView.setBackgroundColor(0x33ff0000);
						settings.edit().putBoolean(pacsForAdapter[position].packageName + "/" + pacsForAdapter[position].name + "?hidden", false).apply();
						notifyDataSetChanged();
					} else {
						finalConvertView.setBackgroundColor(0x0);
						settings.edit().putBoolean(pacsForAdapter[position].packageName + "/" + pacsForAdapter[position].name + "?hidden", true).apply();
						notifyDataSetChanged();
					}
				}
			});
	
			return convertView;
		}
	}
}

