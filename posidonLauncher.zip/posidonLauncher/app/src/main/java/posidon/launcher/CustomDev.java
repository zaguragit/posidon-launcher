/*
 * Copyright (c) 2019 Leo Shneyderis
 * All rights reserved
 */

package posidon.launcher;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.WindowManager;
import android.widget.Switch;


public class CustomDev extends AppCompatActivity {

    private SharedPreferences settings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
		super.onCreate(savedInstanceState);
        setContentView(R.layout.customdev);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        findViewById(R.id.settings).setPadding(0, 0, 0,Tools.getNavbarHeight(this));
        ((Switch)findViewById(R.id.showcomponent)).setChecked(settings.getBoolean("showcomponent", false));
    }

    @Override
    protected void onPause() {
		super.onPause();
        overridePendingTransition(R.anim.slideup, R.anim.slidedown);
        SharedPreferences.Editor e = settings.edit();
        e.putBoolean("showcomponent", ((Switch)findViewById(R.id.showcomponent)).isChecked());
        e.apply();
        Main.customized = true;
    }
}