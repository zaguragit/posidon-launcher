package posidon.launcher.wall;

import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Build;
import android.widget.Toast;

import java.io.IOException;
import java.lang.ref.WeakReference;

public class SetWall extends AsyncTask {
	
	Bitmap img;
	WeakReference<Context> cr;
	
	public SetWall(Bitmap img, Context context) {
		this.img = img;
		this.cr = new WeakReference<>(context);
	}
	
	@Override
	protected Object doInBackground(Object[] objects) {
		WallpaperManager myWallpaperManager = WallpaperManager.getInstance(cr.get().getApplicationContext());
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			if(myWallpaperManager.isWallpaperSupported()) {
				try { myWallpaperManager.setBitmap(img); }
				catch (IOException ignored) {}
			}
		} else {
			try { myWallpaperManager.setBitmap(img); }
			catch (IOException ignored) {}
		}
		return null;
	}
}