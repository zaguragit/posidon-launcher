package posidon.launcher;

import android.annotation.SuppressLint;
import android.app.ActivityOptions;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.preference.PreferenceManager;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.widget.NestedScrollView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.palette.graphics.Palette;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Xml;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_COLLAPSED;

public class Main extends AppCompatActivity {
	
	private static final int REQUEST_PICK_APPWIDGET = 0;
	private static final int REQUEST_CREATE_APPWIDGET = 1;
	public static boolean shouldsetapps = false;
	public static boolean customized;

	private Pac[] pacs;
	private PackageManager pm;
	private SharedPreferences settings;
	private GridView drawergrid;
	private View searchbar;
	BottomSheetBehavior behavior;
	private RecyclerView feedrecycler;
	private RecyclerView notifications;
	private NestedScrollView desktop;
	private PacReceiver receiver;
	private ImageView blurbg;
	AppWidgetManager widgetManager;
	AppWidgetHost widgetHost;
	AppWidgetHostView hostView;
	AppWidgetHostView hostView2;

	@SuppressLint("ClickableViewAccessibility")
	@Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
		if (settings.getBoolean("init", true)) {
			startActivity(new Intent(this, Tutorial.class));
			finish();
		}
		pm = getPackageManager();
		desktop = findViewById(R.id.desktop);

		IntentFilter filter = new IntentFilter();
		filter.addAction(Intent.ACTION_PACKAGE_ADDED);
		filter.addAction(Intent.ACTION_PACKAGE_REMOVED);
		filter.addAction(Intent.ACTION_PACKAGE_CHANGED);
		filter.addDataScheme("package");
		receiver = new PacReceiver();
		registerReceiver(receiver, filter);
		
		drawergrid = findViewById(R.id.searchresults);
		searchbar = findViewById(R.id.searchbar);
		drawergrid.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_DOWN && drawergrid.canScrollVertically(-1)) drawergrid.requestDisallowInterceptTouchEvent(true);
				return false;
			}
		});
		
		behavior = BottomSheetBehavior.from(findViewById(R.id.drawer));
		behavior.setState(STATE_COLLAPSED);
		behavior.setHideable(false);
		behavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
			@Override
			public void onStateChanged(@NonNull View bottomSheet, int newState) {
				if (newState == STATE_COLLAPSED) {
					findViewById(R.id.realdock).getBackground().setAlpha(255);
					findViewById(R.id.drawerhandle).setVisibility(View.VISIBLE);
					drawergrid.smoothScrollToPositionFromTop(0, 0, 0);
				} else {
					findViewById(R.id.drawerhandle).setVisibility(View.GONE);
					findViewById(R.id.realdock).getBackground().setAlpha(0);
				}
			}
			@Override
			public void onSlide(@NonNull View bottomSheet, float slideOffset) {
				float a = slideOffset * 1.2f*(2 + slideOffset);
				drawergrid.setAlpha(slideOffset);
				ShapeDrawable bg = (ShapeDrawable) findViewById(R.id.drawercontent).getBackground();
				float tr = (float)settings.getInt("dockradius", 30) * getResources().getDisplayMetrics().density * (1 - slideOffset);
				bg.getPaint().setColor(ColorTools.blendColors(settings.getInt("drawercolor", 0x88000000), settings.getInt("dockcolor", 0x88000000), slideOffset));
				bg.setShape(new RoundRectShape(new float[]{tr, tr ,tr, tr, 0, 0, 0, 0}, null, null));
				if (settings.getBoolean("blur", false)) blurbg.setAlpha(a);
				desktop.setAlpha(1 - a);
				desktop.setTranslationY(-500 * slideOffset);
				findViewById(R.id.realdock).setAlpha(1 - a);
				findViewById(R.id.realdock).setTranslationY((-bottomSheet.getHeight() + findViewById(R.id.realdock).getHeight()) * slideOffset);
			}
		});
		
		setapps(drawergrid);
		feedrecycler = findViewById(R.id.feedrecycler);
		feedrecycler.setNestedScrollingEnabled(false);
		if (settings.getBoolean("feedenabled", true)) new FetchFeedTask(settings, feedrecycler).execute((Void) null);
		
		findViewById(R.id.widgets).setOnLongClickListener(new LongPressMenu(Main.this, settings, getWindow()));
		final ScaleGestureDetector scaleGestureDetector = new ScaleGestureDetector(Main.this, new LongPressMenu.PinchListener(Main.this, settings, getWindow()));
		findViewById(R.id.homeview).setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_UP && behavior.getState() == STATE_COLLAPSED) WallpaperManager.getInstance(Main.this).sendWallpaperCommand(v.getWindowToken(), WallpaperManager.COMMAND_TAP, (int)event.getX(), (int)event.getY(), 0, null);
				return false;
			}
		});
		findViewById(R.id.desktop).setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				scaleGestureDetector.onTouchEvent(event);
				return false;
			}
		});
		
		if (settings.getBoolean("mnmlstatus", false)) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LOW_PROFILE);
		else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
		findViewById(R.id.searchbar).setPadding(0, 0, 0, Tools.getNavbarHeight(this));
		findViewById(R.id.searchresults).setPadding(0, Tools.getStatusBarHeight(Main.this), 0, 0);
		setcustoms();
		
		if (settings.getBoolean("blur", false)) {
			blurbg = findViewById(R.id.blur);
			blurbg.setImageBitmap(Tools.wallblurbitmap(Main.this, settings.getFloat("blurradius", 25)));
		}
		try {
			if (NotificationManagerCompat.getEnabledListenerPackages (getApplicationContext()).contains(getApplicationContext().getPackageName())) {
				startService(new Intent(this, NotificationListener.class));
				if (NotificationListener.notifications != null && NotificationListener.notifications.length > 0) {
					notifications = findViewById(R.id.notifications);
					notifications.setNestedScrollingEnabled(false);
					notifications.setLayoutManager(new LinearLayoutManager(this));
					notifications.setAdapter(new NotificationsAdapter(this, settings));
				}
			}
		} catch (Exception e) {}
		
		widgetManager = AppWidgetManager.getInstance(this);
		widgetHost = new AppWidgetHost(this, R.id.widgets);
		widgetHost.startListening();
		findViewById(R.id.widgets).setPadding(0, Tools.getStatusBarHeight(this), 0, 0);
		createWidget();
		
		System.gc();
	}

	void selectWidget() {
		int appWidgetId = widgetHost.allocateAppWidgetId();
		Intent pickIntent = new Intent(AppWidgetManager.ACTION_APPWIDGET_PICK);
		pickIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
		ArrayList customInfo = new ArrayList();
		pickIntent.putParcelableArrayListExtra(AppWidgetManager.EXTRA_CUSTOM_INFO, customInfo);
		ArrayList customExtras = new ArrayList();
		pickIntent.putParcelableArrayListExtra(AppWidgetManager.EXTRA_CUSTOM_EXTRAS, customExtras);
		startActivityForResult(pickIntent, REQUEST_PICK_APPWIDGET);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK ) {
			if (requestCode == REQUEST_PICK_APPWIDGET) {
				Bundle extras = data.getExtras();
				int appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);
				AppWidgetProviderInfo appWidgetInfo = widgetManager.getAppWidgetInfo(appWidgetId);
				if (appWidgetInfo.configure != null) {
					Intent intent = new Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE);
					intent.setComponent(appWidgetInfo.configure);
					intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
					startActivityForResult(intent, REQUEST_CREATE_APPWIDGET);
				} else createWidget(data);
			} else if (requestCode == REQUEST_CREATE_APPWIDGET) createWidget(data);
		} else if (resultCode == RESULT_CANCELED && data != null) {
			int appWidgetId = data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);
			if (appWidgetId != -1) widgetHost.deleteAppWidgetId(appWidgetId);
		}
	}
	
	public void createWidget(Intent data) {
		try {
			widgetHost.deleteAppWidgetId(hostView2.getAppWidgetId());
			((LinearLayout) findViewById(R.id.widgets)).removeView(hostView2);
		} catch (NullPointerException ignore) {}
		
		Bundle extras = data.getExtras();
		int appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);
		AppWidgetProviderInfo appWidgetInfo = widgetManager.getAppWidgetInfo(appWidgetId);
		hostView = widgetHost.createView(getApplicationContext(), appWidgetId, appWidgetInfo);
		hostView.setAppWidget(appWidgetId, appWidgetInfo);
		((LinearLayout)findViewById(R.id.widgets)).addView(hostView);
		if (!widgetManager.bindAppWidgetIdIfAllowed(appWidgetId, appWidgetInfo.provider)) {
			// Request permission - https://stackoverflow.com/a/44351320/1816603
			Intent intent = new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND);
			intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
			intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, appWidgetInfo.provider);
			final int REQUEST_BIND_WIDGET = 1987;
			startActivityForResult(intent, REQUEST_BIND_WIDGET);
		}
		settings.edit().putString("widget", appWidgetInfo.provider.getPackageName()+"/"+appWidgetInfo.provider.getClassName()).apply();
		hostView2 = hostView;
		hostView = null;
	}
	
	public boolean createWidget() {
		String[] s = settings.getString("widget", "posidon.launcher/posidon.launcher.ClockWidget").split("/");
		String packageName = s[0];
		String className;
		try { className = s[1]; }
		catch (ArrayIndexOutOfBoundsException ignored) { return false; }
		
		// Get the list of installed widgets
		AppWidgetProviderInfo newAppWidgetProviderInfo = null;
		List<AppWidgetProviderInfo> appWidgetInfos = widgetManager.getInstalledProviders();
		boolean widgetIsFound = false;
		for(int j = 0; j < appWidgetInfos.size(); j++) {
			if (appWidgetInfos.get(j).provider.getPackageName().equals(packageName) && appWidgetInfos.get(j).provider.getClassName().equals(className)) {
				// Get the full info of the required widget
				newAppWidgetProviderInfo = appWidgetInfos.get(j);
				widgetIsFound = true;
				break;
			}
		}
		
		if (!widgetIsFound) return false;
		else {
			// Create Widget
			int appWidgetId = widgetHost.allocateAppWidgetId();
			hostView = widgetHost.createView(getApplicationContext(), appWidgetId, newAppWidgetProviderInfo);
			hostView.setAppWidget(appWidgetId, newAppWidgetProviderInfo);
			
			// Add it to your layout
			LinearLayout widgetLayout = findViewById(R.id.widgets);
			widgetLayout.addView(hostView);
			
			// And bind widget IDs to make them actually work
			if (!widgetManager.bindAppWidgetIdIfAllowed(appWidgetId, newAppWidgetProviderInfo.provider)) {
				// Request permission - https://stackoverflow.com/a/44351320/1816603
				Intent intent = new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND);
				intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
				intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, newAppWidgetProviderInfo.provider);
				final int REQUEST_BIND_WIDGET = 1987;
				startActivityForResult(intent, REQUEST_BIND_WIDGET);
			}
			hostView2 = hostView;
			hostView = null;
			return true;
		}
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		if (settings.getBoolean("feedenabled", true)) new FetchFeedTask(settings, feedrecycler).execute((Void) null);
		IntentFilter filter = new IntentFilter();
		filter.addAction(Intent.ACTION_PACKAGE_ADDED);
		filter.addAction(Intent.ACTION_PACKAGE_REMOVED);
		filter.addAction(Intent.ACTION_PACKAGE_CHANGED);
		filter.addDataScheme("package");
		receiver = new PacReceiver();
		registerReceiver(receiver, filter);
		if (settings.getBoolean("blur", false)) {
			blurbg = findViewById(R.id.blur);
			blurbg.setImageBitmap(Tools.wallblurbitmap(Main.this, settings.getFloat("blurradius", 25)));
		} if (customized) {
			setcustoms();
			customized = false;
			shouldsetapps = false;
		} else {
			PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
			if (!powerManager.isPowerSaveMode() && settings.getBoolean("animatedicons", true)) for (Pac pac : pacs) Tools.animate(pac.icon);
		}
		System.gc();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		behavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
		unregisterReceiver(receiver);
		widgetHost.stopListening();
		System.gc();
	}
	
	@Override
	protected void onStop() {
		super.onStop();
		widgetHost.stopListening();
		try { widgetHost.deleteAppWidgetId(hostView.getAppWidgetId()); }
		catch (Exception ignored) {}
		((LinearLayout)findViewById(R.id.widgets)).removeView(hostView);
	}
	
	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		if (hasFocus) {
			try {
				if (NotificationManagerCompat.getEnabledListenerPackages(getApplicationContext()).contains(getApplicationContext().getPackageName())) {
					if (NotificationListener.notifications != null && NotificationListener.notifications.length > 0)
						notifications.setAdapter(new NotificationsAdapter(this, settings));
					else {
						startService(new Intent(this, NotificationListener.class));
						if (NotificationListener.notifications != null && NotificationListener.notifications.length > 0)
							notifications.setAdapter(new NotificationsAdapter(this, settings));
					}
				}
			} catch (Exception ignored) {}
			if (settings.getBoolean("mnmlstatus", false))
				getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LOW_PROFILE);
		} else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
	}
	
	private void setapps(GridView grid) {
		int skippedapps = 0;
		List<ResolveInfo> pacslist = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
		pacs = new Pac[pacslist.size()];
		
		final int ICONSIZE = Tools.numtodp(65, this);
		Resources themeRes = null;
		String resPacName;
		resPacName = settings.getString("iconpack", "posidon.launcher");
		String iconResource;
		int intres;
		int intresiconback = 0;
		int intresiconfront = 0;
		int intresiconmask = 0;
		float scaleFactor;
		Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
		p.setAntiAlias(true);
		Paint origP = new Paint(Paint.FILTER_BITMAP_FLAG);
		origP.setAntiAlias(true);
		Paint maskp= new Paint(Paint.FILTER_BITMAP_FLAG);
		maskp.setAntiAlias(true);
		maskp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
		if (resPacName != null && resPacName.compareTo("") != 0) {
			try { themeRes = pm.getResourcesForApplication(resPacName); }
			catch(Exception ignored) {}
			if (themeRes != null) {
				String[] backAndMaskAndFront = ThemeTools.getIconBackAndMaskResourceName(themeRes, resPacName);
				if (backAndMaskAndFront[0] != null) intresiconback = themeRes.getIdentifier(backAndMaskAndFront[0],"drawable", resPacName);
				if (backAndMaskAndFront[1] != null) intresiconmask = themeRes.getIdentifier(backAndMaskAndFront[1],"drawable", resPacName);
				if (backAndMaskAndFront[2] != null) intresiconfront = themeRes.getIdentifier(backAndMaskAndFront[2],"drawable", resPacName);
			}
		}
		BitmapFactory.Options uniformOptions = new BitmapFactory.Options();
		uniformOptions.inScaled = false;
		Canvas origCanv;
		Canvas canvas;
		scaleFactor = ThemeTools.getScaleFactor(themeRes, resPacName);
		Bitmap back = null;
		Bitmap mask = null;
		Bitmap front = null;
		Bitmap scaledBitmap;
		Bitmap scaledOrig;
		Bitmap orig;
		
		if (resPacName != null && resPacName.compareTo("") != 0 && themeRes != null) {
			if (intresiconback != 0) back = BitmapFactory.decodeResource(themeRes, intresiconback, uniformOptions);
			if (intresiconmask != 0) mask = BitmapFactory.decodeResource(themeRes, intresiconmask, uniformOptions);
			if (intresiconfront != 0) front = BitmapFactory.decodeResource(themeRes, intresiconfront, uniformOptions);
		}
		
		for (int i = 0; i < pacslist.size(); i++) {
			if (settings.getBoolean(pacslist.get(i).activityInfo.packageName + "/" + pacslist.get(i).activityInfo.name + "?hidden", false)) skippedapps++;
			else {
				pacs[i-skippedapps] = new Pac();
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
					try { pacs[i-skippedapps].icon = adaptic(pm.getActivityIcon(new ComponentName(pacslist.get(i).activityInfo.packageName, pacslist.get(i).activityInfo.name))); }
					catch (Exception e) { e.printStackTrace(); }
				} else pacs[i-skippedapps].icon = pacslist.get(i).loadIcon(pm);
				pacs[i-skippedapps].packageName = pacslist.get(i).activityInfo.packageName;
				pacs[i-skippedapps].name = pacslist.get(i).activityInfo.name;
				pacs[i-skippedapps].label = settings.getString(pacs[i-skippedapps].packageName + "/" + pacs[i-skippedapps].name + "?label", pacslist.get(i).loadLabel(pm).toString());
				
				intres = 0;
				iconResource = ThemeTools.getResourceName(themeRes, resPacName, "ComponentInfo{" + pacs[i - skippedapps].packageName + "/" + pacs[i - skippedapps].name + "}");
				if (iconResource != null) intres = Objects.requireNonNull(themeRes).getIdentifier(iconResource, "drawable", resPacName);
				if (intres != 0) try {
					//Do NOT add the theme parameter to getDrawable()
					pacs[i - skippedapps].icon = themeRes.getDrawable(intres);
					PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
					if (!powerManager.isPowerSaveMode() && settings.getBoolean("animatedicons", true)) Tools.animate(pacs[i - skippedapps].icon);
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) pacs[i - skippedapps].icon = adaptic(pacs[i - skippedapps].icon);
				} catch (Exception e) { e.printStackTrace(); } else {
					orig = Bitmap.createBitmap(pacs[i - skippedapps].icon.getIntrinsicWidth(), pacs[i - skippedapps].icon.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
					pacs[i - skippedapps].icon.setBounds(0, 0, pacs[i - skippedapps].icon.getIntrinsicWidth(), pacs[i - skippedapps].icon.getIntrinsicHeight());
					pacs[i - skippedapps].icon.draw(new Canvas(orig));
					scaledOrig = Bitmap.createBitmap(ICONSIZE, ICONSIZE, Bitmap.Config.ARGB_8888);
					scaledBitmap = Bitmap.createBitmap(ICONSIZE, ICONSIZE, Bitmap.Config.ARGB_8888);
					canvas = new Canvas(scaledBitmap);
					if (back != null) canvas.drawBitmap(back, Tools.getResizedMatrix(back, ICONSIZE, ICONSIZE), p);
					origCanv = new Canvas(scaledOrig);
					orig = Tools.getResizedBitmap(orig, ((int) (ICONSIZE * scaleFactor)), ((int) (ICONSIZE * scaleFactor)));
					origCanv.drawBitmap(orig, scaledOrig.getWidth() - (orig.getWidth() / 2) - scaledOrig.getWidth() / 2, scaledOrig.getWidth() - (orig.getWidth() / 2) - scaledOrig.getWidth() / 2, origP);
					if (mask != null) origCanv.drawBitmap(mask, Tools.getResizedMatrix(mask, ICONSIZE, ICONSIZE), maskp);
					if (back != null) canvas.drawBitmap(Tools.getResizedBitmap(scaledOrig, ICONSIZE, ICONSIZE), 0, 0, p);
					else canvas.drawBitmap(Tools.getResizedBitmap(scaledOrig, ICONSIZE, ICONSIZE), 0, 0, p);
					if (front != null) canvas.drawBitmap(front, Tools.getResizedMatrix(front, ICONSIZE, ICONSIZE), p);
					pacs[i - skippedapps].icon = new BitmapDrawable(getResources(), scaledBitmap);
				}
			}
		}
		pacs = Arrays.copyOf(pacs, pacs.length - skippedapps);
		new SortApps().exchange_sort(pacs);
		grid.setAdapter(new DrawerAdapter(this, pacs));
		grid.setOnItemLongClickListener(new DrawerLongClickListener(this, pacs, settings));
		grid.setOnItemClickListener(new DrawerClickListener(Main.this, pacs));
	}
	void setdock() {
		BottomSheetBehavior behavior = BottomSheetBehavior.from(findViewById(R.id.drawer));
		int p = settings.getInt("dockicsize", 1);
		int appsize = 0;
		if (p == 0) appsize = (int) (getResources().getDisplayMetrics().density * 64);
		else if (p == 1) appsize = (int) (getResources().getDisplayMetrics().density * 72);
		else if (p == 2) appsize = (int) (getResources().getDisplayMetrics().density * 96);
		int[] txt = {R.id.icontxt1, R.id.icontxt2, R.id.icontxt3, R.id.icontxt4, R.id.icontxt5, R.id.icontxt6, R.id.icontxt7};
		int[] img = {R.id.iconimg1, R.id.iconimg2, R.id.iconimg3, R.id.iconimg4, R.id.iconimg5, R.id.iconimg6, R.id.iconimg7};
		int icnum = settings.getInt("dockiccount", 5);
		int[] icids = {R.id.ic1, R.id.ic2, R.id.ic3, R.id.ic4, R.id.ic5, R.id.ic6, R.id.ic7};
		String[] items = {"ic1", "ic2", "ic3", "ic4", "ic5", "ic6", "ic7"};
		for (int x = 0; x < icnum; x++) {
			findViewById(icids[x]).setVisibility(View.VISIBLE);
			ImageView ic = findViewById(img[x]);
			ic.getLayoutParams().height = appsize;
			ic.getLayoutParams().width = appsize;
			TextView t = findViewById(txt[x]);
			if (settings.getBoolean("docklabelsenabled", false)) t.setVisibility(View.VISIBLE);
			else t.setVisibility(View.GONE);
		}
		for (Pac pac : pacs) {
			for (int x = 0; x < icnum; x++) {
				if ((pac.packageName + pac.name).equals(settings.getString(items[x], ""))) {
					findViewById(icids[x]).setOnClickListener(new dockclick(this, pac));
					findViewById(icids[x]).setOnLongClickListener(new docklongclick(this, items[x], pac));
					((ImageView) findViewById(img[x])).setImageDrawable(pac.icon);
					TextView t = findViewById(txt[x]);
					t.setText(pac.label);
				} else if (Objects.requireNonNull(settings.getString(items[x], "")).equals("")) {
					((ImageView) findViewById(img[x])).setImageDrawable(getDrawable(android.R.color.transparent));
					findViewById(icids[x]).setOnClickListener(null);
					findViewById(icids[x]).setOnLongClickListener(null);
				}
			}
		} behavior.setPeekHeight((int)(
				appsize +
				getResources().getDisplayMetrics().density * ((settings.getBoolean("docklabelsenabled", false)) ? 26 : 10) +
				((settings.getBoolean("docksearchbarenabled", false)) ? 56 * getResources().getDisplayMetrics().density : 0) +
				Tools.getNavbarHeight(this) +
				settings.getInt("dockbottompadding", 10) * getResources().getDisplayMetrics().density
		));
	}
	private void setcustoms() {
		ShapeDrawable bg = new ShapeDrawable();
		float tr = settings.getInt("dockradius", 30) * getResources().getDisplayMetrics().density;
		bg.setShape(new RoundRectShape(new float[]{tr, tr ,tr, tr, 0, 0, 0, 0}, null, null));
		bg.getPaint().setColor(settings.getInt("drawercolor", 0x88000000));
		findViewById(R.id.drawercontent).setBackground(bg);
		bg = new ShapeDrawable();
		bg.setShape(new RoundRectShape(new float[]{tr, tr ,tr, tr, 0, 0, 0, 0}, null, null));
		int color = settings.getInt("dockcolor", 0x88000000);
		bg.getPaint().setColor(color);
		findViewById(R.id.realdock).setBackground(bg);
		findViewById(R.id.realdock).setPadding(0, 0, 0, Tools.getNavbarHeight(this) + (int)(settings.getInt("dockbottompadding", 10) * getResources().getDisplayMetrics().density));
		
		bg = new ShapeDrawable();
		tr = settings.getInt("searchradius", 0) * getResources().getDisplayMetrics().density;
		bg.setShape(new RoundRectShape(new float[]{tr, tr ,tr, tr, 0, 0, 0, 0}, null, null));
		bg.getPaint().setColor(settings.getInt("searchcolor", 0x33000000));
		searchbar.setBackground(bg);
		TextView t = findViewById(R.id.searchtxt);
		t.setTextColor(settings.getInt("searchhintcolor", 0xFFFFFFFF));
		t.setText(settings.getString("searchhinttxt", "Search.."));
		
		if (settings.getBoolean("docksearchbarenabled", false)) {
			findViewById(R.id.docksearchbar).setVisibility(View.VISIBLE);
			bg = new ShapeDrawable();
			tr = settings.getInt("docksearchradius", 30) * getResources().getDisplayMetrics().density;
			bg.setShape(new RoundRectShape(new float[]{tr, tr ,tr, tr, tr, tr, tr, tr}, null, null));
			bg.getPaint().setColor(settings.getInt("docksearchcolor", 0xDDFFFFFF));
			findViewById(R.id.docksearchbar).setBackground(bg);
			t = findViewById(R.id.docksearchtxt);
			t.setTextColor(settings.getInt("docksearchtxtcolor", 0xFF000000));
			t.setText(settings.getString("searchhinttxt", "Search.."));
			((ImageView)findViewById(R.id.docksearchic)).setImageTintList(new ColorStateList(new int[][]{new int[]{0}}, new int[]{settings.getInt("docksearchtxtcolor", 0xFF000000)}));
		} else findViewById(R.id.docksearchbar).setVisibility(View.GONE);
		
		setTheme(settings.getInt("fonttheme", R.style.hometheme_posidonsans));
		drawergrid.setNumColumns(settings.getInt("numcolumns", 4));
		drawergrid.setVerticalSpacing((int)(getResources().getDisplayMetrics().density * settings.getInt("verticalspacing", 12)));
		if (settings.getBoolean("feedenabled", true)) {
			feedrecycler.setVisibility(View.VISIBLE);
			feedrecycler.setLayoutManager(new LinearLayoutManager(this));
		}
		else feedrecycler.setVisibility(View.GONE);
		if (settings.getBoolean("hidefeed", false)) {
			feedrecycler.setAlpha(0);
			feedrecycler.setTranslationY(findViewById(R.id.homeview).getHeight());
			desktop.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
				@Override
				public void onScrollChange(NestedScrollView v, int x, int y, int oldx, int oldy) {
					if (y > 6) {
						feedrecycler.setTranslationY(0);
						feedrecycler.setAlpha(1);
					} else if (oldy > 6 && y < 6) {
						feedrecycler.setTranslationY(findViewById(R.id.homeview).getHeight());
						feedrecycler.setAlpha(0);
					}
				}
			});
		} else {
			feedrecycler.setAlpha(1);
			feedrecycler.setTranslationY(0);
			desktop.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {public void onScrollChange(NestedScrollView nestedScrollView, int x, int y, int x2, int y2) {}});
		}
		if (shouldsetapps) setapps(drawergrid);
		setdock();
		if (settings.getBoolean("hidestatus", false)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
	}
	
	@RequiresApi(api = Build.VERSION_CODES.O)
	private Drawable adaptic(Drawable drawable) {
		if (settings.getInt("icshape", 4) == 0) return drawable;
		else if (drawable instanceof AdaptiveIconDrawable || settings.getBoolean("reshapeicons", false)) {
			Drawable[] drr = new Drawable[2];
			if (drawable instanceof AdaptiveIconDrawable) {
				AdaptiveIconDrawable aid = ((AdaptiveIconDrawable) drawable);
				drr[0] = aid.getBackground();
				drr[1] = aid.getForeground();
			} else {
				drr[0] = new ColorDrawable(0xFFFFFFFF);
				BitmapDrawable d = (BitmapDrawable)drawable;
				Bitmap b = Bitmap.createBitmap(d.getIntrinsicWidth(), d.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
				Canvas c = new Canvas(b);
				d.setBounds(c.getWidth() / 4, c.getHeight() / 4, c.getWidth() / 4 * 3, c.getHeight() / 4 * 3);
				drawable.draw(c);
				drr[1] = new BitmapDrawable(getResources(), b);
			}
			LayerDrawable layerDrawable = new LayerDrawable(drr);
			int width = layerDrawable.getIntrinsicWidth();
			int height = layerDrawable.getIntrinsicHeight();
			Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
			Canvas canvas = new Canvas(bitmap);
			layerDrawable.setBounds(-canvas.getWidth() / 4, -canvas.getHeight() / 4, canvas.getWidth() / 4 * 5, canvas.getHeight() / 4 * 5);
			layerDrawable.draw(canvas);
			Bitmap outputBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
			canvas = new Canvas(outputBitmap);
			if (settings.getInt("icshape", 4) != 3) {
				final Path path = new Path();
				if (settings.getInt("icshape", 4) == 1)
					path.addCircle((float)width / 2f + 1, (float)height / 2f + 1, Math.min(width, ((float)height / 2f)) - 2, Path.Direction.CCW);
				else if (settings.getInt("icshape", 4) == 2)
					path.addRoundRect(2, 2, width - 2, height - 2, (float)Math.min(width, height) / 4f, (float)Math.min(width, height) / 4f, Path.Direction.CCW);
				else if (settings.getInt("icshape", 4) == 4) {
					//Formula: (|x|)^3 + (|y|)^3 = radius^3
					int xx = 2, yy = 2, radius = Math.min(width, height) / 2 - 2;
					final double radiusToPow = radius * radius * radius;
					path.moveTo(-radius, 0);
					for (int x = -radius ; x <= radius ; x++)
						path.lineTo(x, ((float) Math.cbrt(radiusToPow - Math.abs(x * x * x))));
					for (int x = radius ; x >= -radius ; x--)
						path.lineTo(x, ((float) -Math.cbrt(radiusToPow - Math.abs(x * x * x))));
					path.close();
					
					Matrix matrix = new Matrix();
					matrix.postTranslate(xx + radius, yy + radius);
					path.transform(matrix);
				}
				canvas.clipPath(path);
			}
			Paint p = new Paint();
			p.setAntiAlias(true);
			p.setFilterBitmap(true);
			canvas.drawBitmap(bitmap, 0, 0, p);
			bitmap = outputBitmap;
			return new BitmapDrawable(getResources(), bitmap);
		} else return drawable;
	}
	public class PacReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
        	setapps(drawergrid);
        	setdock();
        	System.gc();
        }
    }
	
	@Override
	public void onBackPressed() { behavior.setState(STATE_COLLAPSED); }
	
	class docklongclick implements View.OnLongClickListener {

		final Context context;
		final String item;
		final Pac pac;
		Dialog d;

		docklongclick(Context c, String icon, Pac p){
			context = c;
			item = icon;
			pac = p;
		}

		@Override
		public boolean onLongClick(View v) {
			Tools.vibrate(Main.this);
			d = new Dialog(context);
			d.setContentView(R.layout.applongpressmenu);

			WindowManager.LayoutParams wmlp = Objects.requireNonNull(d.getWindow()).getAttributes();
			wmlp.gravity = Gravity.BOTTOM | Gravity.START;
			wmlp.x = (int)v.getX() + (int)findViewById(R.id.dockcontainer).getX();
			wmlp.y = (int)(v.getY() + v.getHeight() + Tools.getNavbarHeight(context) + (settings.getInt("dockbottompadding", 10) + 12) * getResources().getDisplayMetrics().density);

			TextView title = d.findViewById(R.id.appnametxt);
			TextView appinfobtn = d.findViewById(R.id.appinfobtn);
			TextView editbtn = d.findViewById(R.id.editbtn);
			

			int color = Palette.from(Tools.drawable2bitmap(pac.icon)).generate().getDominantColor(0xFF252627);
			final float[] hsv = new float[3];
			Color.colorToHSV(color, hsv);
			if (hsv[2] > 0.9f) {
				color = Palette.from(Tools.drawable2bitmap(pac.icon)).generate().getVibrantColor(0xFF252627);
				Color.colorToHSV(color, hsv);
			}
			ShapeDrawable bg = new ShapeDrawable();
			float r = 25 * getResources().getDisplayMetrics().density;
			bg.setShape(new RoundRectShape(new float[]{r, r, r, r, r, r, r, r}, null, null));
			bg.getPaint().setColor(color);
			d.findViewById(R.id.bg).setBackground(bg);
			int txtcolor;
			if (Color.green(color) > 200) txtcolor = 0xFF000000;
			else txtcolor = 0xFFFFFFFF;
			title.setText(pac.label);
			title.setTextColor(txtcolor);
			
			TextView changebtn = d.findViewById(R.id.changebtn);
			changebtn.setTextColor(txtcolor);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) changebtn.setCompoundDrawableTintList(new ColorStateList(new int[][]{new int[]{0}}, new int[]{txtcolor}));
			changebtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					d.dismiss();
					settings.edit().putString(item, "").apply();
					setdock();
				}
			});
			
			appinfobtn.setTextColor(txtcolor);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) appinfobtn.setCompoundDrawableTintList(new ColorStateList(new int[][]{new int[]{0}}, new int[]{txtcolor}));
			appinfobtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) { d.dismiss(); appinfo(pac, Color.HSVToColor(new float[]{hsv[0], hsv[1], 0.4f})); }
			});

			editbtn.setTextColor(txtcolor);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) editbtn.setCompoundDrawableTintList(new ColorStateList(new int[][]{new int[]{0}}, new int[]{txtcolor}));
			editbtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					d.setContentView(R.layout.appeditmenu);
					final EditText editlabel = d.findViewById(R.id.editlabel);
					editlabel.setText(settings.getString(pac.packageName + "/" + pac.name + "?label", pac.label));
					d.setOnDismissListener(new DialogInterface.OnDismissListener() {
						@Override
						public void onDismiss(DialogInterface dialog) {
							settings.edit().putString(pac.packageName + "/" + pac.name + "?label", editlabel.getText().toString()).apply();
							setapps(drawergrid);
							setdock();
						}
					});
				}
			});
			
			d.show();
			return true;
		}
	}
	class DrawerLongClickListener implements AdapterView.OnItemLongClickListener {

		private final Context context;
		private final Pac[] pacsForAdapter;
		private final SharedPreferences settings;

		DrawerLongClickListener(Context c, Pac[] pacs, SharedPreferences s) {
			context = c;
			pacsForAdapter = pacs;
			settings = s;
		}
		
		@Override
		public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
			Tools.vibrate(Main.this);
			final Dialog dialog = new Dialog(context);
			dialog.setContentView(R.layout.applongpressmenu);
			
			int color = Palette.from(Tools.drawable2bitmap(pacs[position].icon)).generate().getDominantColor(0xFF252627);
			final float[] hsv = new float[3];
			Color.colorToHSV(color, hsv);
			if (hsv[2] > 0.9f) {
				color = Palette.from(Tools.drawable2bitmap(pacs[position].icon)).generate().getVibrantColor(0xFF252627);
				Color.colorToHSV(color, hsv);
			}
			ShapeDrawable bg = new ShapeDrawable();
			float r = 25 * getResources().getDisplayMetrics().density;
			bg.setShape(new RoundRectShape(new float[]{r, r, r, r, r, r, r, r}, null, null));
			bg.getPaint().setColor(color);
			dialog.findViewById(R.id.bg).setBackground(bg);
			final int txtcolor;
			if (Color.green(color) > 190) txtcolor = 0xFF000000;
			else txtcolor = 0xFFFFFFFF;
			
			TextView title = dialog.findViewById(R.id.appnametxt);
			title.setText(pacsForAdapter[position].label);
			title.setTextColor(txtcolor);
			
			
			final WindowManager.LayoutParams wmlp = Objects.requireNonNull(dialog.getWindow()).getAttributes();
			if (view.getY() < parent.getHeight() / 2) {
				wmlp.gravity = Gravity.TOP | Gravity.START;
				int[] location = {0, 0};
				view.findViewById(R.id.iconimg).getLocationInWindow(location);
				wmlp.x = location[0];
				wmlp.y = location[1] + Tools.getStatusBarHeight(Main.this);
			} else {
				wmlp.gravity = Gravity.BOTTOM | Gravity.START;
				int[] location = {0, 0};
				view.findViewById(R.id.iconimg).getLocationInWindow(location);
				wmlp.x = location[0];
				wmlp.y = context.getResources().getDisplayMetrics().heightPixels - location[1];
			}
			
			TextView addtodockbtn = dialog.findViewById(R.id.changebtn);
			addtodockbtn.setTextColor(txtcolor);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) addtodockbtn.setCompoundDrawableTintList(new ColorStateList(new int[][]{new int[]{0}}, new int[]{txtcolor}));
			addtodockbtn.setText("Add to dock");
			addtodockbtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dialog.dismiss();
					new DockMenu(Main.this, getWindow(), pacsForAdapter[position]);
				}
			});
			
			TextView appinfobtn = dialog.findViewById(R.id.appinfobtn);
			appinfobtn.setTextColor(txtcolor);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) appinfobtn.setCompoundDrawableTintList(new ColorStateList(new int[][]{new int[]{0}}, new int[]{txtcolor}));
			appinfobtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) { dialog.dismiss(); appinfo(pacsForAdapter[position], Color.HSVToColor(new float[]{hsv[0], hsv[1], 0.4f})); }
			});
			TextView editbtn = dialog.findViewById(R.id.editbtn);
			editbtn.setTextColor(txtcolor);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) editbtn.setCompoundDrawableTintList(new ColorStateList(new int[][]{new int[]{0}}, new int[]{txtcolor}));
			editbtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					wmlp.gravity = Gravity.CENTER;
					wmlp.x = 0;
					wmlp.y = 0;
					dialog.setContentView(R.layout.appeditmenu);
					final EditText editlabel = dialog.findViewById(R.id.editlabel);
					editlabel.setText(settings.getString(pacsForAdapter[position].packageName + "/" + pacsForAdapter[position].name + "?label", pacsForAdapter[position].label));
					dialog.dismiss();
					dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
						@Override
						public void onDismiss(DialogInterface dialog) {
							settings.edit().putString(pacsForAdapter[position].packageName + "/" + pacsForAdapter[position].name + "?label", editlabel.getText().toString()).apply();
							setapps(drawergrid);
						}
					});
					dialog.show();
				}
			});
			dialog.show();
			return true;
		}
	}
	
	private void appinfo(final Pac pac, int appcolor) {
		final BottomSheetDialog d = new BottomSheetDialog(Main.this, R.style.bottomsheet);
		d.setContentView(R.layout.appinfo);
		ShapeDrawable g = new ShapeDrawable();
		float tr = 25 * getResources().getDisplayMetrics().density, lr = 10 * getResources().getDisplayMetrics().density;
		float[] radii = new float[] {tr, tr, tr, tr, lr, lr, lr, lr};
		g.setShape(new RoundRectShape(radii, null ,null));
		g.getPaint().setColor(appcolor);
		Objects.requireNonNull(d.getWindow()).findViewById(R.id.design_bottom_sheet).setBackground(g);
		((TextView) Objects.requireNonNull(d.findViewById(R.id.appname))).setText(pac.label);
		((ImageView) Objects.requireNonNull(d.findViewById(R.id.iconimg))).setImageBitmap(Tools.drawable2bitmap(pac.icon));
		try { ((TextView) Objects.requireNonNull(d.findViewById(R.id.version))).setText(pm.getPackageInfo(pac.packageName, 0).versionName); }
		catch (PackageManager.NameNotFoundException ignored) {}
		if (settings.getBoolean("showcomponent", false)) {
			((TextView) Objects.requireNonNull(d.findViewById(R.id.componentname))).setText(pac.packageName + "/" + pac.name);
			Objects.requireNonNull(d.findViewById(R.id.component)).setVisibility(View.VISIBLE);
		}
		Objects.requireNonNull(d.findViewById(R.id.openinsettings)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.setData(Uri.parse("package:" + pac.packageName));
                startActivity(i, ActivityOptions.makeCustomAnimation(Main.this, R.anim.slideup, R.anim.slidedown).toBundle());
            }
        });
		Objects.requireNonNull(d.findViewById(R.id.uninstallbtn)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
				Tools.vibrate(Main.this);
                d.dismiss();
                Intent uninstallintent = new Intent("android.intent.action.DELETE");
                uninstallintent.setData(Uri.parse("package:" + pac.packageName));
                startActivity(uninstallintent);
            }
        });
		d.show();
	}
	public void searchdialog(View view) {
		startActivity(new Intent(this, SearchActivity.class));
		SearchActivity.pacs = pacs;
	}

	class FetchFeedTask extends AsyncTask<Void, Void, Boolean> {

		List<FeedItem> mFeedModelList;
		final SharedPreferences settings;
		final RecyclerView recycler;

		FetchFeedTask(SharedPreferences s, RecyclerView r) {
			settings = s;
			recycler = r;
		}

		@Override
		protected Boolean doInBackground(Void... voids) {
			String urlLink = settings.getString("feedurl", "www.androidauthority.com/feed");
			if (!TextUtils.isEmpty(urlLink)) try {
				if(!Objects.requireNonNull(urlLink).startsWith("http://") && !urlLink.startsWith("https://")) urlLink = "https://" + urlLink;
				mFeedModelList = parseFeed(new URL(urlLink).openConnection().getInputStream());
				return true;
			} catch (Exception ignored) {}
			return false;
		}
		@Override
		protected void onPostExecute(Boolean success) {
			if (success) recycler.setAdapter(new FeedAdapter(mFeedModelList, recycler.getContext(), settings, getWindow()));
		}
		
		private List<FeedItem> parseFeed(InputStream inputStream) throws XmlPullParserException, IOException {
			String title = null, link = null;
			Bitmap img = null;
			boolean isItem = false;
			List<FeedItem> items = new ArrayList<>();
			try {
				XmlPullParser parser = Xml.newPullParser();
				parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
				parser.setInput(inputStream, null);
				parser.nextTag();
				while (parser.next() != XmlPullParser.END_DOCUMENT) {
					int eventType = parser.getEventType();
					String name = parser.getName();
					if(name == null) continue;
					if(eventType == XmlPullParser.END_TAG) {
						if(name.equalsIgnoreCase("item")) isItem = false;
						continue;
					}
					if (eventType == XmlPullParser.START_TAG) {
						if(name.equalsIgnoreCase("item")) {
							isItem = true;
							continue;
						}
					}
					String result = "";
					if (parser.next() == XmlPullParser.TEXT) {
						result = parser.getText();
						parser.nextTag();
					}
					if (name.equalsIgnoreCase("title")) title = result;
					else if (name.equalsIgnoreCase("link")) link = result;
					else if (name.equalsIgnoreCase("media:content")) img = BitmapFactory.decodeStream((InputStream)new URL(parser.getAttributeValue(1)).getContent());
					else if (name.equalsIgnoreCase("image") && img == null) img = BitmapFactory.decodeStream((InputStream)new URL(result).getContent());

					if (title != null && link != null && img != null) {
						if(isItem) items.add(new FeedItem(title, link, img));
						title = null;
						link = null;
						img = null;
						isItem = false;
					}
				}
				return items;
			} finally { inputStream.close(); }
		}
	}
}