package posidon.launcher;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.GridView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SearchActivity extends AppCompatActivity {
	
	static Pac[] pacs;
	
	@Override
	public void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.searchlayout);
		SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
		EditText searchtxt = findViewById(R.id.searchtxt);
		final GridView searchgrid = findViewById(R.id.searchgrid);
		search("", searchgrid);
		searchtxt.requestFocus();
		searchtxt.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
			@Override
			public void afterTextChanged(Editable s) {}
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) { search(s.toString(), searchgrid); }
		});
		InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
		ShapeDrawable bg = new ShapeDrawable();
		bg.setShape(new RectShape());
		bg.getPaint().setColor(settings.getInt("searchuibg", 0x88000000));
		getWindow().setBackgroundDrawable(bg);
		searchtxt.setTextColor(settings.getInt("searchtxtcolor", 0xFFFFFFFF));
		searchtxt.setHintTextColor(settings.getInt("searchhintcolor", 0xFFFFFFFF));
		searchtxt.setHint(settings.getString("searchhinttxt", "Search.."));
		findViewById(R.id.kill).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				kill();
			}
		});
	}
	
	private void search(String string, GridView grid) {
		int j = 0;
		for (Pac pac : pacs) { if (cook(pac.label).startsWith(cook(string)) && j < 10) j++; }
		Pac[] results = new Pac[j];
		j = 0;
		for (Pac pac : pacs) {
			if (cook(pac.label).startsWith(cook(string)) && j < 10) {
				results.clone();
				results[j] = pac;
				j++;
			}
		}
		grid.setAdapter(new SearchAdapter(this, results));
		grid.setOnItemClickListener(new DrawerClickListener(this, results));
	}
	
	@Override
	protected void onPause() {
		kill();
		super.onPause();
	}
	
	private String cook(String s) {
		return s.toLowerCase()
				.replace(" ", "")
				.replace(",", "")
				.replace(".", "")
				.replace("ñ", "n")
				.replace("ck", "c")
				.replace("cc", "c")
				.replace("z", "s")
				.replace("wh", "w")
				.replace("ts", "s");
	}
	
	private void kill() {
		hideKeyboard(this);
		finish();
	}
	
	private static void hideKeyboard(Activity activity) {
		InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
		//Find the currently focused view, so we can grab the correct window token from it.
		View view = activity.getCurrentFocus();
		//If no view currently has focus, create a new one, just so we can grab a window token from it
		if (view == null) {
			view = new View(activity);
		}
		imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
	}
}