package posidon.launcher

internal class SortApps {
    fun exchange_sort(pacs: Array<Pac>) {
        var i: Int
        var j: Int
        var temp: Pac
        i = 0
        while (i < pacs.size - 1) {
            j = i + 1
            while (j < pacs.size) {
                if (pacs[i].label.compareTo(pacs[j].label, ignoreCase = true) > 0) {
                    temp = pacs[i]
                    pacs[i] = pacs[j]
                    pacs[j] = temp
                }
                j++
            }
            i++
        }
    }
}
