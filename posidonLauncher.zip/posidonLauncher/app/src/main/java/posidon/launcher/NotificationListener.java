package posidon.launcher;

import android.app.NotificationChannelGroup;
import android.content.Intent;
import android.os.UserHandle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class NotificationListener extends NotificationListenerService {
	
	public static StatusBarNotification[] notifications = new StatusBarNotification[0];
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		notifications = getActiveNotifications();
		return super.onStartCommand(intent, flags, startId);
	}
	
	@Override
	public void onNotificationPosted(StatusBarNotification sbn) {
		notifications = getActiveNotifications();
	}
	
	@Override
	public void onNotificationRemoved(StatusBarNotification sbn) {
		notifications = getActiveNotifications();
	}
	
	@Override
	public void onNotificationRemoved(StatusBarNotification sbn, RankingMap rankingMap, int reason) {
		notifications = getActiveNotifications();
	}
	
	@Override
	public void onNotificationChannelGroupModified(String pkg, UserHandle user, NotificationChannelGroup group, int modificationType) {
		notifications = getActiveNotifications();
	}
	
	@Override
	public void onNotificationRankingUpdate(RankingMap rankingMap) {
		notifications = getActiveNotifications();
	}
}
