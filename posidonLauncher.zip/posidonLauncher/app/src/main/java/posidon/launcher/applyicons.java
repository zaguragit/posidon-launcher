package posidon.launcher;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

public class applyicons extends AppCompatActivity {

    @SuppressLint("ApplySharedPref")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        try {
            settings.edit()
                    .putString("iconpack", Objects.requireNonNull(getIntent().getExtras()).getString("iconpack"))
                    .commit();
        }
        catch (NullPointerException ignored) {}
        finish();
        startActivity(new Intent(this, Main.class));
    }

}
