package posidon.launcher;

import android.graphics.drawable.Drawable;

class Pac {
    Drawable icon;
    String name;
    String packageName;
    String label;
}
