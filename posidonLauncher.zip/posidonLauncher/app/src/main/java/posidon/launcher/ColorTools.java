package posidon.launcher;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.io.IOException;
import java.util.Objects;

public class ColorTools {
	
	static int blendColors(int color1, int color2, float ratio) {
		final float inverseRation = 1f - ratio;
		float a = (Color.alpha(color1) * ratio) + (Color.alpha(color2) * inverseRation);
		float r = (Color.red(color1) * ratio) + (Color.red(color2) * inverseRation);
		float g = (Color.green(color1) * ratio) + (Color.green(color2) * inverseRation);
		float b = (Color.blue(color1) * ratio) + (Color.blue(color2) * inverseRation);
		return Color.argb((int) a, (int) r, (int) g, (int) b);
	}
	
	static Drawable colorcircle(int color) {
		ShapeDrawable d = new ShapeDrawable();
		d.setShape(new OvalShape());
		d.getPaint().setColor(color);
		return d;
	}
	
	public static void pickcolor(final Context context, final String settingskey, final SharedPreferences settings, int defaultcolor) {
		final BottomSheetDialog d = new BottomSheetDialog(context, R.style.bottomsheet);
		d.setContentView(R.layout.colorpicker);
		Objects.requireNonNull(d.getWindow()).findViewById(R.id.design_bottom_sheet).setBackgroundResource(R.drawable.bottomsheet);
		final EditText txt = d.findViewById(R.id.hextxt);
		Objects.requireNonNull(txt).addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after){}
			@Override
			public void afterTextChanged(Editable s) {}
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				try { Objects.requireNonNull(d.findViewById(R.id.colorprev)).setBackgroundColor((int)Long.parseLong(s.toString(), 16)); }
				catch (NumberFormatException ignored) {}
			}
		});
		txt.setText(Integer.toHexString(settings.getInt(settingskey, defaultcolor)));
		Objects.requireNonNull(d.findViewById(R.id.ok)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				d.dismiss();
				try { settings.edit().putInt(settingskey, (int)Long.parseLong(txt.getText().toString(), 16)).apply(); }
				catch (NumberFormatException e) { Toast.makeText(context, "That's not a color.", Toast.LENGTH_SHORT).show(); }
			}
		});
		final SeekBar alpha = d.findViewById(R.id.alpha);
		final SeekBar red = d.findViewById(R.id.red);
		final SeekBar green = d.findViewById(R.id.green);
		final SeekBar blue = d.findViewById(R.id.blue);
		StringBuilder hex = new StringBuilder(txt.getText().toString());
		while (hex.length()!=8) hex.insert(0, 0);
		Objects.requireNonNull(alpha).setProgress((int)Long.parseLong(hex.substring(0, 2), 16));
		Objects.requireNonNull(red).setProgress((int)Long.parseLong(hex.substring(2, 4), 16));
		Objects.requireNonNull(green).setProgress((int)Long.parseLong(hex.substring(4, 6), 16));
		Objects.requireNonNull(blue).setProgress((int)Long.parseLong(hex.substring(6, 8), 16));
		alpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				txt.setText(Integer.toHexString(progress*256*256*256+red.getProgress()*256*256+green.getProgress()*256+blue.getProgress()));
			}
		});
		red.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				txt.setText(Integer.toHexString(alpha.getProgress()*256*256*256+progress*256*256+green.getProgress()*256+blue.getProgress()));
			}
		});
		green.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				txt.setText(Integer.toHexString(alpha.getProgress()*256*256*256+red.getProgress()*256*256+progress*256+blue.getProgress()));
			}
		});
		blue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				txt.setText(Integer.toHexString(alpha.getProgress()*256*256*256+red.getProgress()*256*256+green.getProgress()*256+progress));
			}
		});
		System.gc();
		d.show();
	}
	
	public static void pickwallcolor(final Context context) {
		final BottomSheetDialog d = new BottomSheetDialog(context, R.style.bottomsheet);
		d.setContentView(R.layout.colorpicker);
		Objects.requireNonNull(d.getWindow()).findViewById(R.id.design_bottom_sheet).setBackgroundResource(R.drawable.bottomsheet);
		final EditText txt = d.findViewById(R.id.hextxt);
		Objects.requireNonNull(txt).addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after){}
			@Override
			public void afterTextChanged(Editable s) {}
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				try { Objects.requireNonNull(d.findViewById(R.id.colorprev)).setBackgroundColor((int)Long.parseLong("ff"+s.toString(), 16)); }
				catch (NumberFormatException ignored) {}
			}
		});
		txt.setText("000000");
		Objects.requireNonNull(d.findViewById(R.id.ok)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				d.dismiss();
				try { WallpaperManager myWallpaperManager = WallpaperManager.getInstance(context);
					Bitmap c = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
					c.eraseColor((int)Long.parseLong("ff"+txt.getText().toString(), 16));
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
						if(myWallpaperManager.isWallpaperSupported()){
							try { myWallpaperManager.setBitmap(c); }
							catch (IOException ignored) {}
						} else Toast.makeText(context, "For some reason wallpapers are not supported.", Toast.LENGTH_LONG).show();
					} else {
						try { myWallpaperManager.setBitmap(c); }
						catch (IOException ignored) {}
					}
					context.startActivity(new Intent(context, Main.class)); }
				catch (NumberFormatException e) { Toast.makeText(context, "That's not a color.", Toast.LENGTH_SHORT).show(); }
			}
		});
		Objects.requireNonNull(d.findViewById(R.id.alpha)).setVisibility(View.GONE);
		final SeekBar red = d.findViewById(R.id.red);
		final SeekBar green = d.findViewById(R.id.green);
		final SeekBar blue = d.findViewById(R.id.blue);
		Objects.requireNonNull(red).setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				StringBuilder hex = new StringBuilder(Integer.toHexString(progress * 256 * 256 + Objects.requireNonNull(green).getProgress() * 256 + Objects.requireNonNull(blue).getProgress()));
				while (hex.length()!=6) hex.insert(0, 0);
				txt.setText(hex.toString());
			}
		});
		Objects.requireNonNull(green).setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				StringBuilder hex = new StringBuilder(Integer.toHexString(red.getProgress() * 256 * 256 + progress * 256 + Objects.requireNonNull(blue).getProgress()));
				while (hex.length()!=6) hex.insert(0, 0);
				txt.setText(hex.toString());
			}
		});
		Objects.requireNonNull(blue).setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				StringBuilder hex = new StringBuilder(Integer.toHexString(red.getProgress() * 256 * 256 + green.getProgress() * 256 + progress));
				while (hex.length()!=6) hex.insert(0, 0);
				txt.setText(hex.toString());
			}
		});
		System.gc();
		d.show();
	}
}
