/*
 * Copyright (c) 2019 Leo Shneyderis
 * All rights reserved
 */

package posidon.launcher;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;


public class CustomSearch extends AppCompatActivity {

    private SharedPreferences settings;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customsearch);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        findViewById(R.id.settings).setPadding(0, 0, 0,Tools.getNavbarHeight(this));
        
        findViewById(R.id.searchcolorprev).setBackground(ColorTools.colorcircle(settings.getInt("searchcolor", 0x33000000)));
        findViewById(R.id.searchtxtcolorprev).setBackground(ColorTools.colorcircle(settings.getInt("searchtxtcolor", 0xFFFFFFFF)));
        findViewById(R.id.searchhintcolorprev).setBackground(ColorTools.colorcircle(settings.getInt("searchhintcolor", 0xFFFFFFFF)));
        ((TextView)findViewById(R.id.hinttxt)).setText(settings.getString("searchhinttxt", "Search.."));
        ((SeekBar)findViewById(R.id.searchradiusslider)).setProgress(settings.getInt("searchradius", 0));
        ((Switch)findViewById(R.id.docksearchbar)).setChecked(settings.getBoolean("docksearchbarenabled", false));
        findViewById(R.id.docksearchcolorprev).setBackground(ColorTools.colorcircle(settings.getInt("docksearchcolor", 0xDDFFFFFF)));
        findViewById(R.id.docksearchtxtcolorprev).setBackground(ColorTools.colorcircle(settings.getInt("docksearchtxtcolor", 0xFF000000)));
        ((SeekBar)findViewById(R.id.docksearchradiusslider)).setProgress(settings.getInt("docksearchradius", 30));
    }

	public void picksearchcolor(View v) { ColorTools.pickcolor(this, "searchcolor", settings, 0x33000000); }
	public void picksearchtxtcolor(View v) { ColorTools.pickcolor(this, "searchtxtcolor", settings, 0xFFFFFFFF); }
	public void picksearchhintcolor(View v) { ColorTools.pickcolor(this, "searchhintcolor", settings, 0xFFFFFFFF); }
    public void pickdocksearchcolor(View v) { ColorTools.pickcolor(this, "docksearchcolor", settings, 0x0); }
    public void pickdocksearchtxtcolor(View v) { ColorTools.pickcolor(this, "docksearchtxtcolor", settings, 0x0); }

    @Override
    protected void onPause() {
        overridePendingTransition(R.anim.slideup, R.anim.slidedown);
        SharedPreferences.Editor e = settings.edit();
        e.putString("searchhinttxt", ((TextView)findViewById(R.id.hinttxt)).getText().toString());
        e.putInt("searchradius", ((SeekBar)findViewById(R.id.searchradiusslider)).getProgress());
        e.putBoolean("docksearchbarenabled", ((Switch)findViewById(R.id.docksearchbar)).isChecked());
        e.apply();
        Main.customized = true;
        super.onPause();
    }
}