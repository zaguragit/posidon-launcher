/*
 * Copyright (c) 2019 Leo Shneyderis
 * All rights reserved
 */

package posidon.launcher;

import android.content.SharedPreferences;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.view.WindowManager;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;


public class CustomDrawer extends AppCompatActivity {

    private SharedPreferences settings;
    private SeekBar icsize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customdrawer);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        findViewById(R.id.settings).setPadding(0, 0, 0,Tools.getNavbarHeight(this));

        icsize = findViewById(R.id.iconsizeslider);
        icsize.setProgress(settings.getInt("icsize", 1));
    
        final SeekBar columnslider = findViewById(R.id.columnslider);
        columnslider.setProgress(settings.getInt("numcolumns", 4) - 1);
        final TextView c = findViewById(R.id.columnnum);
        c.setText(String.valueOf(settings.getInt("numcolumns", 4)));
        columnslider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                c.setText(String.valueOf(progress + 1));
                settings.edit().putInt("numcolumns", progress + 1).apply();
            }
        });
    
        final SeekBar verticalspacingslider = findViewById(R.id.verticalspacingslider);
        verticalspacingslider.setProgress(settings.getInt("verticalspacing", 12));
        final TextView verticalspacingnum = findViewById(R.id.verticalspacingnum);
        verticalspacingnum.setText(String.valueOf(settings.getInt("verticalspacing", 12)));
        verticalspacingslider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                verticalspacingnum.setText(String.valueOf(progress));
                settings.edit().putInt("verticalspacing", progress).apply();
            }
        });

        ((Switch)findViewById(R.id.labelsenabled)).setChecked(settings.getBoolean("labelsenabled", true));
        findViewById(R.id.colorprev).setBackground(ColorTools.colorcircle(settings.getInt("drawercolor", 0x88000000)));
        
        ((Switch)findViewById(R.id.blurswitch)).setChecked(settings.getBoolean("blur", false));
        SeekBar blurslider = findViewById(R.id.blurslider);
        blurslider.setProgress((int)settings.getFloat("blurradius",25));
        blurslider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                getWindow().setBackgroundDrawable(new BitmapDrawable(getResources(), Tools.wallblurbitmap(CustomDrawer.this, progress)));
                settings.edit().putFloat("blurradius", progress).apply();
            }
        });
    }

	public void pickcolor(View v) { ColorTools.pickcolor(this, "drawercolor", settings, 0x88000000); }

    @Override
    protected void onPause() {
        overridePendingTransition(R.anim.slideup, R.anim.slidedown);
        SharedPreferences.Editor e = settings.edit();
        e.putInt("icsize", icsize.getProgress());
        e.putBoolean("labelsenabled", ((Switch)findViewById(R.id.labelsenabled)).isChecked());
        e.putBoolean("blur", ((Switch)findViewById(R.id.blurswitch)).isChecked());
        e.apply();
        Main.customized = true;
        super.onPause();
    }
}