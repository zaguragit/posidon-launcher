package posidon.launcher.wall;

import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.AdapterView;
import posidon.launcher.R;

class GalleryItemClick implements AdapterView.OnItemClickListener {

    private final Context c;
    private final Wall[] walls;
    public static Bitmap img;
    public static String url;

    GalleryItemClick(Context context, Wall[] walllist) {
        c = context;
        walls = walllist;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent i = new Intent(c, WallpaperActivity.class);
        i.putExtra("name", walls[position].name);
        i.putExtra("author", walls[position].author);
        img = walls[position].img;
        url = walls[position].url;
        c.startActivity(i, ActivityOptions.makeCustomAnimation(c, R.anim.slideup, R.anim.slidedown).toBundle());
        System.gc();
    }
}
