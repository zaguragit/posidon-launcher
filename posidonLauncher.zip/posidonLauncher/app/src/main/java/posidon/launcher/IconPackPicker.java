package posidon.launcher;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;
import java.util.Objects;

public class IconPackPicker extends AppCompatActivity {
	
	private SharedPreferences settings;
	private View lastclicked;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		settings = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
		setContentView(R.layout.iconpackpicker);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
		findViewById(R.id.settings).setPadding(0, 0, 0,Tools.getNavbarHeight(this));
		PackageManager pm = getPackageManager();
		lastclicked = findViewById(R.id.systemicons);
		
		findViewById(R.id.systemicons).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				settings.edit().putString("iconpack", "system").apply();
				v.setBackground(getDrawable(R.drawable.selection));
				lastclicked.setBackgroundColor(0x0);
				lastclicked = v;
			}
		});
		
		Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
		mainIntent.addCategory("com.anddoes.launcher.THEME");
		List<ResolveInfo> pacslist = pm.queryIntentActivities(mainIntent, 0);
		final Pac[] pacs = new Pac[pacslist.size()];
		for (int i = 0; i < pacslist.size(); i++) {
			pacs[i] = new Pac();
			pacs[i].icon = pacslist.get(i).loadIcon(pm);
			pacs[i].packageName = pacslist.get(i).activityInfo.packageName;
			pacs[i].label = pacslist.get(i).loadLabel(pm).toString();
		}
		GridView grid = findViewById(R.id.grid);
		grid.setAdapter(new IconPackListAdapter(this, pacs));
		grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				settings.edit().putString("iconpack", pacs[position].packageName).apply();
				view.setBackground(getDrawable(R.drawable.selection));
				lastclicked.setBackgroundColor(0x0);
				lastclicked = view;
			}
		});
	}
	
	class IconPackListAdapter extends BaseAdapter {
		
			private final Context context;
			private final Pac[] pacsForAdapter;
		
			IconPackListAdapter(Context c, Pac[] pacs){
				context = c;
				pacsForAdapter = pacs;
			}
		
			@Override
			public int getCount() {
				return pacsForAdapter.length;
			}
		
			@Override
			public Object getItem(int position) {
				return null;
			}
		
			@Override
			public long getItemId(int position) {
				return 0;
			}
		
			class ViewHolder{
				ImageView icon;
				TextView text;
			}
		
			@Override
			public View getView(final int position, View convertView, ViewGroup parent) {
				final SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(context);
				ViewHolder viewHolder;
				LayoutInflater li = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
		
				if (convertView==null){
					convertView = li.inflate(R.layout.listitem, null);
					viewHolder = new ViewHolder();
					viewHolder.icon = convertView.findViewById(R.id.iconimg);
					viewHolder.text = convertView.findViewById(R.id.icontxt);
					convertView.setTag(viewHolder);
				}
				else viewHolder = (ViewHolder)convertView.getTag();
				viewHolder.icon.setImageDrawable(pacsForAdapter[position].icon);
				viewHolder.text.setText(pacsForAdapter[position].label);
				int p = settings.getInt("icsize", 1);
				if (p == 0) {viewHolder.icon.setPadding(64, 64, 64, 64);}
				else if (p == 1) {viewHolder.icon.setPadding(32, 32, 32, 32);}
				else if (p == 2) {viewHolder.icon.setPadding(0, 0, 0, 0);}
				if (Objects.requireNonNull(settings.getString("iconpack", "system")).equals(pacsForAdapter[position].packageName)) {
					convertView.setBackground(getDrawable(R.drawable.selection));
					lastclicked = convertView;
				}
				else convertView.setBackgroundColor(0x0);
				return convertView;
			}
		}
}
