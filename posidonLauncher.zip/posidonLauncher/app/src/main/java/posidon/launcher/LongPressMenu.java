package posidon.launcher;

import android.app.ActivityOptions;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.Window;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import java.util.Objects;

class LongPressMenu implements View.OnLongClickListener {

    private final Context context;
    private final SharedPreferences settings;
    private final Window window;

    LongPressMenu(Context context, SharedPreferences settings, Window window) {
        this.context = context;
        this.settings = settings;
        this.window = window;
    }

    @Override
    public boolean onLongClick(View v) {
        menu(context, settings, window);
        return true;
    }
    
    static class PinchListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        
        private final Context context;
        private final SharedPreferences settings;
        private final Window window;
        
        PinchListener(Context context, SharedPreferences settings, Window window) {
            this.context = context;
            this.settings = settings;
            this.window = window;
        }
        
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            return true;
        }
    
        @Override
        public void onScaleEnd(ScaleGestureDetector detector) {
            menu(context, settings, window);
        }
    }
    
    private static void menu(final Context context, final SharedPreferences settings, final Window window) {
        Tools.vibrate(context);
        final BottomSheetDialog bottomdialog = new BottomSheetDialog(context, R.style.longpressmenusheet);
        bottomdialog.setContentView(R.layout.menu);
        final View homescreen = window.getDecorView().findViewById(android.R.id.content);
        final View page = homescreen.findViewById(R.id.homeview);
        final View dock = homescreen.findViewById(R.id.realdock);
        float t = (float)-page.getHeight()/14;
        page.animate().scaleX(0.7f).scaleY(0.7f).translationY(t).setDuration(100L);
        Objects.requireNonNull(bottomdialog.getWindow()).findViewById(R.id.design_bottom_sheet).setBackgroundResource(R.drawable.blackgradient);
        Objects.requireNonNull(bottomdialog.findViewById(R.id.custombtn)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.setComponent(new ComponentName("posidon.launcher", "posidon.launcher.Customizations"));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                context.startActivity(i, ActivityOptions.makeCustomAnimation(context, R.anim.slideup, R.anim.slidedown).toBundle());
                bottomdialog.dismiss();
            }
        });
        Objects.requireNonNull(bottomdialog.findViewById(R.id.wallbtn)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.setComponent(new ComponentName("posidon.launcher", "posidon.launcher.wall.Gallery"));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                context.startActivity(i, ActivityOptions.makeCustomAnimation(context, R.anim.slideup, R.anim.slidedown).toBundle());
                bottomdialog.dismiss();
            }
        });
        Objects.requireNonNull(bottomdialog.findViewById(R.id.widgets)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((Main)context).selectWidget();
                bottomdialog.dismiss();
            }
        });
        final float tr = (float)settings.getInt("dockradius", 30) * context.getResources().getDisplayMetrics().density;
        bottomdialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                page.animate().scaleX(1).scaleY(1).translationY(0).setDuration(100L);
                page.setBackgroundColor(0x0);
                window.setBackgroundDrawableResource(android.R.color.transparent);
                ((ShapeDrawable)dock.getBackground()).setShape(new RoundRectShape(new float[]{tr, tr ,tr, tr, 0, 0, 0, 0}, null, null));
            }
        });
        page.setBackground(context.getDrawable(R.drawable.page));
        window.setBackgroundDrawableResource(R.drawable.blackgradient);
        window.setBackgroundDrawable(new BitmapDrawable(context.getResources(), Tools.wallblurbitmap(context, settings.getFloat("blurradius", 25))));
        float br = context.getResources().getDisplayMetrics().density * 35;
        ((ShapeDrawable)dock.getBackground()).setShape(new RoundRectShape(new float[]{tr, tr ,tr, tr, br, br, br, br}, null, null));
        bottomdialog.show();
    }
}
