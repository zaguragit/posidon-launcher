package posidon.launcher;

import android.app.ActivityOptions;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;

class dockclick implements View.OnClickListener {

    private final Context context;
    private final Pac pac;

    public dockclick(Context c, Pac p) {
        context = c;
        pac = p;
    }

	@Override
    public void onClick(View v) {
        try {
            Intent launchintent = new Intent(Intent.ACTION_MAIN);
            launchintent.addCategory(Intent.CATEGORY_LAUNCHER);
            launchintent.setComponent(new ComponentName(pac.packageName, pac.name));
            launchintent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            //This shit could've been the app opening animation if it wasn't so slow
            //ActivityOptions options = ActivityOptions.makeScaleUpAnimation(v, 0, 0, 100, 100);
            context.startActivity(launchintent, ActivityOptions.makeCustomAnimation(context, R.anim.appopen, R.anim.slidedown).toBundle());
        } catch (Exception ignored) {}
    }
}