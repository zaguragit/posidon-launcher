package posidon.launcher;

import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import org.jetbrains.annotations.NotNull;
import java.util.List;

public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.FeedModelViewHolder> {

	private final Context context;
	private final List<FeedItem> FeedModels;
	private final SharedPreferences settings;
	private final Window window;

	FeedAdapter(List<FeedItem> FeedModels, Context context, SharedPreferences settings, Window window) {
		this.FeedModels = FeedModels;
		this.context = context;
		this.settings = settings;
		this.window = window;
	}

	static class FeedModelViewHolder extends RecyclerView.ViewHolder {
		private final View rssFeedView;
		FeedModelViewHolder(View v) {
			super(v);
			rssFeedView = v;
		}
	}

	@NotNull
	@Override
	public FeedModelViewHolder onCreateViewHolder(@NotNull ViewGroup parent, int type) {
		View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.newscard, parent, false);
		return new FeedModelViewHolder(v);
	}

	@Override
	public void onBindViewHolder(@NotNull final FeedModelViewHolder holder, int position) {
		final FeedItem feedItem = FeedModels.get(position);
		((TextView)holder.rssFeedView.findViewById(R.id.titletxt)).setText(feedItem.title);
		((TextView)holder.rssFeedView.findViewById(R.id.titletxt)).setTextColor(settings.getInt("newscardtxtcolor", 0xFFFFFFFF));
		if(settings.getBoolean("newscardimgenabled", true) && feedItem.img != null) {
			((ImageView)holder.rssFeedView.findViewById(R.id.img)).setImageBitmap(feedItem.img);
		} else {
			holder.rssFeedView.findViewById(R.id.img).setVisibility(View.GONE);
			holder.rssFeedView.findViewById(R.id.card).getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
			holder.rssFeedView.findViewById(R.id.titletxt).getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
			holder.rssFeedView.findViewById(R.id.gradient).getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
		}
		holder.rssFeedView.findViewById(R.id.card).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) { context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(feedItem.link)), ActivityOptions.makeCustomAnimation(context, R.anim.slideup, R.anim.slidedown).toBundle()); }
		});
		holder.rssFeedView.findViewById(R.id.card).setOnLongClickListener(new LongPressMenu(context, settings, window));
		((CardView)holder.rssFeedView.findViewById(R.id.card)).setRadius(context.getResources().getDisplayMetrics().density * settings.getInt("feedcardradius", 15));
		((CardView)holder.rssFeedView.findViewById(R.id.card)).setCardBackgroundColor(settings.getInt("newscardcolor", 0xFF252627));
		if (!settings.getBoolean("newscardblackgradient", true)) holder.rssFeedView.findViewById(R.id.gradient).setVisibility(View.GONE);
	}

	@Override
	public int getItemCount() { return FeedModels.size(); }
}
