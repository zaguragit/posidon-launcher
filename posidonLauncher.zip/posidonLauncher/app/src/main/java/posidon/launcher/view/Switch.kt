package posidon.launcher.view

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import posidon.launcher.R
import posidon.launcher.Tools

class Switch : android.widget.Switch {

    constructor(context: Context) : super(context) {
        trackDrawable = context.getDrawable(R.drawable.switchtrack)
        thumbDrawable = context.getDrawable(R.drawable.switchthumb)
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        trackDrawable = context.getDrawable(R.drawable.switchtrack)
        thumbDrawable = context.getDrawable(R.drawable.switchthumb)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_DOWN) Tools.vibrate(context)
        return super.onTouchEvent(ev)
    }
}
