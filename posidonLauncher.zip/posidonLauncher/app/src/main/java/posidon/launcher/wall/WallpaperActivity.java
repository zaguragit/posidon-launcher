package posidon.launcher.wall;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import posidon.launcher.R;
import posidon.launcher.Tools;

public class WallpaperActivity extends AppCompatActivity {
    
    private Bitmap img = GalleryItemClick.img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wallpaperview);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        if (img.getHeight() / img.getWidth() < getResources().getDisplayMetrics().heightPixels / getResources().getDisplayMetrics().widthPixels)
            img = Tools.centerCropWallpaper(WallpaperActivity.this, img);
        ((ImageView)findViewById(R.id.theimg)).setImageBitmap(img);
        new loadwall().execute();
        int bottompadding = Tools.getNavbarHeight(this);
        if (bottompadding == 0) bottompadding = (int)(20 * getResources().getDisplayMetrics().density);
        findViewById(R.id.bottomstuff).setPadding(0,0, 0, bottompadding);
        try { ((TextView) findViewById(R.id.nametxt)).setText(Objects.requireNonNull(getIntent().getExtras()).getString("name")); }
        catch (NullPointerException ignored) {}
        try { ((TextView)findViewById(R.id.authortxt)).setText(Objects.requireNonNull(getIntent().getExtras()).getString("author")); }
        catch (NullPointerException ignored) {}
        findViewById(R.id.applybtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SetWall(img, WallpaperActivity.this).execute();
            }
        });
        System.gc();
    }

    @Override
    protected void onPause() {
        overridePendingTransition(R.anim.slideup, R.anim.slidedown);
        super.onPause();
    }
    
    class loadwall extends AsyncTask {
        @Override
        protected Object doInBackground(Object[] objects) {
            try { img = BitmapFactory.decodeStream(new URL(GalleryItemClick.url).openConnection().getInputStream()); }
            catch (IOException e) { e.printStackTrace(); }
            return null;
        }
        @Override
        protected void onPostExecute(Object o) {
            if (img.getHeight() / img.getWidth() < getResources().getDisplayMetrics().heightPixels / getResources().getDisplayMetrics().widthPixels)
                img = Tools.centerCropWallpaper(WallpaperActivity.this, img);
            //else img = Bitmap.createBitmap(img, 0, 0, getResources().getDisplayMetrics().widthPixels, getResources().getDisplayMetrics().widthPixels/img.getWidth()*img.getHeight());
            ((ImageView)findViewById(R.id.theimg)).setImageBitmap(img);
            findViewById(R.id.loading).setVisibility(View.GONE);
        }
    }
}
