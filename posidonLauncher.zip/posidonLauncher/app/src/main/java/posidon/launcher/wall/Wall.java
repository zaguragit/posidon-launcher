package posidon.launcher.wall;

import android.graphics.Bitmap;

class Wall {
    String name;
    String author;
    Bitmap img;
    String url;
}
